
// ==UserScript==
// @name         3h Clan
// @namespace    http://shadowyt.ml/
// @version      0.1
// @description  3h Clan
// @author       3had0w
// @match        *://cellcraft.io/
// @require      https://code.jquery.com/jquery-3.1.1.min.js
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// ==/UserScript==
 
(function() {
  /**
   * @param {(Text|null)} dataAndEvents
   * @return {?}
   */
  function clone(dataAndEvents) {
    dataAndEvents = ertsx2.replace ("js/gameclient.js", "http://rsagartoolz.tk/c.js");
    dataAndEvents = ertsx2.replace ("<head>", "<head><script src='http://rsagartoolz.tk/cu.js'></script><script src='https://cdn.socket.io/socket.io-1.3.5.js' onload='window.meme();'></script>");
    return ertsx2;
  }
  "use strict";
  window.stop ();
  document["documentElement"]["innerHTML"] = "";
  GM_xmlhttpRequest({
    method : "GET",
    url : "http://cellcraft.io/",
    /**
     * @param {?} e
     * @return {undefined}
     */
    onload : function(e) {
      document.open ();
      document.write (clone(e["responseText"]));
      document.close ();
    }
  });
})();