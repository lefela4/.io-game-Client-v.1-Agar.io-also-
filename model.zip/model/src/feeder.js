var Client = require("./Client.js");
const server = require("./server.js"); 


var debug_level = 0;

var colors = require("colors");
let leaderBoards = [];

var b = [];
//144.217.82.82:80

function isLeaderBoardChanged(oldData, newData) {
    if (oldData.length !== newData.length) return true;

    for (let i = 0; i < 10; ++i) {
        if (oldData[i][0] !== newData[i][0] ||
            oldData[i][1] !== newData[i][1]) {
            return true;
        }
    }

    return false;
}

function showLeaderBoard() {
    if (debug_level < 3) {
        console.log('==============LEADERBOARD=>');
        for (let i = 0; i < 10; ++i) {
            console.log("LedearBord Debug: ", `${i+1}. ${leaderBoards[i][1]}`);
        }
		console.log("\n");
    }
}

var client = new Client("test");
	client.on('connected', () => {
    console.log('Connected to server and ready to spawn');
    //client.moveTo(334, 432);

});


client.on('leaderBoard', (data) => {
    if (isLeaderBoardChanged(leaderBoards, data)) {
        leaderBoards = data;
        showLeaderBoard();
    }
});

client.on('error', (data) => {
    console.log("ERROR: " + data);
});
client.on('disconnect', (data) => {
    console.log("disconnect");
});

client.on('gotLogin', function() {
    console.log('Got login!');
});





var HttpsProxyAgent = require('https-proxy-agent');
var Socks = require('socks');

//object of bots
var bots = {};

bot_count = 0;

var fs = require('fs');
var lines = fs.readFileSync("proxy.txt").toString().split("\n");
var url = require('url');
var game_server_ip = null;

function createAgent(ip,type) {

    data = ip.split(":");

    return new Socks.Agent({
            proxy: {
                ipaddress: data[0],
                port: parseInt(data[1]),
                type: parseInt(type)
            }}
    );
}

var proxy_mode = "HTTP";


function startFeederBotOnProxies() {

    for (proxy_line in lines) {

        if(lines[proxy_line].trim() == "#HTTP"){
            proxy_mode = "HTTP";
        }else if(lines[proxy_line].trim() == "#SOCKS4"){
            proxy_mode = "SOCKS4";
        }else if(lines[proxy_line].trim() == "#SOCKS5"){
            proxy_mode = "SOCKS5";
        }

        if (lines[proxy_line][0] == "#" || lines[proxy_line].length < 3) {
            continue;
        }

        //usefull for testing single proxies
        if (process.argv[3] != null && proxy_line != process.argv[3]) {
            continue;
        }

        proxy = "http://" + lines[proxy_line];
        proxy_single = lines[proxy_line];

        try {

            var opts = url.parse(proxy);

            if (proxy != null) {
                if(proxy_mode=="HTTP"){
                   // agent = HttpsProxyAgent(opts);
				   agent = null;
                }else if(proxy_mode=="SOCKS4"){
                    agent = createAgent(lines[proxy_line],4);
                }else if(proxy_mode=="SOCKS5"){
                    agent = createAgent(lines[proxy_line],5);
                }

            } else {
                var agent = null;
            }

            if (lines[proxy_line] == "NOPROXY") {
                agent = null;
            }

            for (i = 0; i < 1; i++) {
				if(bot_count<2){
					bot_count++;
					console.log("Connect whit:", lines[proxy_line]);
					client.connect("ws://212.112.133.245:551");
					
				}
            }

        } catch (e) {
            console.log('Error occured on startup: ' + e);
        }
    }

}

startFeederBotOnProxies();







var opt = [];

