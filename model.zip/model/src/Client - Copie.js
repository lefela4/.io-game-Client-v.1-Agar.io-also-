'use strict';
/*process.on('uncaughtException', function(err) {
    console.log('Caught exception: ' + err);
});*/

const colors = require("colors");
const WebSocket = require('ws');
const EventEmitter = require('events').EventEmitter;
const Packet = require('./packet.js');
const PacketDecoder = require('./PacketDecoder');
const packetDecoder = new PacketDecoder();

function decimalToHexString(number) {
    if (number < 0) {
        number = 0xFFFFFFFF + number + 1;
    }

    return number.toString(16).toUpperCase();
}

class Client extends EventEmitter {

    constructor(clientName) {
        console.log(clientName);
        console.log("New bots called whit name: " + clientName);
        super();
		
        this.p1 = 41;
        this.p2 = 158;
        this.p3 = 147;
        this.p4 = 172;
		this.debug = 4;
        this.headers = {
            Origin: 'http://alis.io'
        };
		this.clientName = clientName;
        this.headers = {
            Origin: 'http://alis.io'
        };
		this.client_name      = ""; //name used for log
		this.debug            = 4;           //debug level, 0-5 (5 will output extremely lot of data)
		this.inactive_destroy = 5*60*1000;   //time in ms when to destroy inactive balls
		this.inactive_check   = 10*1000;     //time in ms when to search inactive balls
		this.spawn_interval   = 200;         //time in ms for respawn interval. 0 to disable (if your custom server don't have spawn problems)
		this.spawn_attempts   = 1000;          //how much attempts to spawn before give up (official servers do have unstable spawn problems)
		this.agent            = null;        //agent for connection. Check additional info in readme
		this.local_address    = null;        //local interface to bind to for network connections (IP address of interface)
		this.headers          = {            //headers for WebSocket connection.
			'Origin': 'http://alis.io'
		};
		this.origin="";
		this.myX=Math.random()-0.5;
		this.myY=Math.random()-0.5;
		this.min_x=0;
		this.min_y=0;
		this.aX=-1;
		this.aY=-1;
		this.tick_counter      = 0;    //number of ticks (packet ID 16 counter)
		this.inactive_interval = 0;    //ID of setInterval()
		this.balls             = {};   //all balls
		this.my_balls          = [];   //IDs of my balls
		this.score             = 0;    //my score
		this.leaders           = [];   //IDs of leaders in FFA mode
		this.teams_scores      = [];   //scores of teams in Teams mode
		this.auth_token        = '';   //FaceBook key or Google for mass bots ;)
		this.auth_provider     = 1;    //auth provider. 1 = facebook, 2 = google
		this.spawn_attempt     = 0;    //attempt to spawn
		this.spawn_interval_id = 0;    //ID of setInterval
		this.employees = {
		cAutoRespawn : false,
		cHideId : false,
		cHideServerDisplay : true,
		cHideNames : false,
		cHideSkins : false,
		cShowMass : false,
		cShowGrid : false,
		cTransCells : false,
		cSilentLogin : false,
		cHideChat : false,
		cDisableRainbow : false,
		cTextOutlines : false,
		cHideMinimap : false,
		cHideCoordinates : false,
		cHideFood : false,
		cColoredPing : false,
		cUiEnabled : false,
		cDisableAutoZoom : false,
		cShowScrimHelp : true
		};
		this.origin = "";
		this.myX = Math.random() - 0.5;
		this.myY = Math.random() - 0.5;
		this.min_x = 0;
		this.min_y = 0;
		this.aX = -1;
		this.aY = -1;
		//don't change things below if you don't understand what you're doing
		this.enabled = false;
		this.leardc = "";
		this.tick_counter = 0; //number of ticks (packet ID 16 counter)
		this.inactive_interval = 0; //ID of setInterval()
		this.balls = {}; //all balls
		this.my_balls = []; //IDs of my balls
		this.score = 0; //my score
		this.item = [];
		this.leaders = []; //IDs of leaders in FFA mode
		this.teams_scores = []; //scores of teams in Teams mode
		this.auth_token = ''; //auth token. Check README.md how to get it
		this.auth_provider = 1; //auth provider. 1 = facebook, 2 = google
		this.spawn_attempt = 0; //attempt to spawn
		this.spawn_interval_id = 0; //ID of setInterval()
		this.setCustomLB = false;
		this.noRanking = false;
		this.teamScores = null;
		this.leaderBoard = [];
		this.spectate = false;
		this.topLevelPrimitive;
		this.suf = "";
		this.playerId = 0;
		this.party = [];
		this.leard = "";
		this.partyIds = {};
		this.border = {};
		this.bucket = [];
		this.stats = {};
		this.foodObjects = [];
		this.sorted = [];
		this.centerSteps = 0;
		this.rainbow = null;
		this.border = {};
		
        this.packetHandlers = {
            '17': function(client, packet) {

var packet = new Packet(packet);
                var x = packet.readFloat32LE(packet.offset, true);
                packet.offset += 4;
                var y = packet.readFloat32LE(packet.offset, true);
                packet.offset += 4;
                var zoom = packet.readFloat32LE(packet.offset, true);
                packet.offset += 4;
                /** @type {number} */
                client.centerSteps = 30;
                if (client.employees.cDisableAutoZoom) {
                    client.scale_base = packet.readFloat32LE(packet.offset, true);
                }

              //  if (client.debug >= 4)
                    console.log('spectate FOV update: x=' + x + ' y=' + y + ' zoom=' + zoom);

                client.emitEvent('spectateFieldUpdate', x, y, zoom);


            },

			18: function(client, packet) { //Nodes Update :D
var packet = new Packet(packet);

            //reading actions of balls
            while(1) {
                var is_virus = false;
                var ball_id;
                var coordinate_x;
                var coordinate_y;
                var size;
				var spiked;
                var color;
                var nick;

                ball_id = packet.readUInt32LE(packet.offset);
				 packet.offset += 4;
                if(ball_id == 0) break;
                coordinate_x = packet.readSInt32LE(packet.offset);
			packet.offset + 2;
                coordinate_y = packet.readSInt32LE(packet.offset);
                size = packet.readSInt16LE(packet.offset + 4);
				spiked = packet.readUInt8(packet.offset + 6);
				packet.offset += 7;
				


                var opt = packet.readUInt8();
                is_virus = !!(opt & 1);
                var something_1 = !!(opt & 16); //todo what is this?
								opt =2;
console.log(opt);
                //reserved for future use?
                if (opt & 2) {
                    var color_R = packet.readUInt8(packet.offset++)
                        var color_G = packet.readUInt8(packet.offset++)
                        var color_B = packet.readUInt8(packet.offset++)

                        color = (color_R << 16 | color_G << 8 | color_B).toString(16);
                        color = '#' + ('000000' + color).substr(-6);

                       var parseEffect = packet.readUInt8(packet.offset++);
                        packet.readUInt16LE(packet.offset, true);
                        packet.offset += 2;
                        
							char = packet.readUInt16LE();
							
							console.log(String.fromCharCode(char));
							if(char == 0) break;
							if(!nick) nick = char;
						console.log(char);
						console.log("color", color, "nick", nick);
					
                }else{
					packet.offset += 5;
					
				}
                if (opt & 4) {
                    var something_2 = ''; //todo something related to premium skins
                    while(1) {
                        var char = packet.readUInt8();
                        if(char == 0) break;
                        if(!something_2) something_2 = '';
                        something_2 += String.fromCharCode(char);
                    }
                }

                /*while(1) {
					
                    char = packet.readUInt16LE();
					
					console.log(String.fromCharCode(char));
                    if(char == 0) break;
                    if(!nick) nick = char;
				console.log(char);
                }*/

                var ball = client.balls[ball_id] || new Ball(client, ball_id);
				
                ball.color = color;
                ball.virus = is_virus;
                ball.setCords(coordinate_x, coordinate_y);
                ball.setSize(size);
                if(nick) ball.setName(nick);
                ball.update_tick = client.tick_counter;
                ball.appear();
                ball.update();

         //       if(client.debug >= 5)
                    console.log('action: ball_id=' + ball_id + ' coordinate_x=' + coordinate_x + ' coordinate_y=' + coordinate_y + ' size=' + size + ' is_virus=' + is_virus + ' nick=' + nick, "spiked=" + spiked);

                client.emitEvent('ballAction', ball_id, coordinate_x, coordinate_y, size, is_virus, nick);
            }
			
            var balls_on_screen_count = packet.readUInt32LE(packet.offset);
			packet.offset += 4;
            //disappear events
            for(var i=0;i<balls_on_screen_count;i++) {
                ball_id = packet.readUInt32LE();

                ball = client.balls[ball_id] || new Ball(client, ball_id);
                ball.update_tick = client.tick_counter;
                ball.update();
                if(ball.mine) {
                    ball.destroy({reason: 'merge'});
                    client.emitEvent('merge', ball.id);
                }else{
                    ball.disappear();
                }
            }

                },
				 '49': function(client, packet) {
					 var packet = new Packet(packet);
            var users = [];
            var count = packet.readUInt32LE(packet.offset);
			 packet.offset += 4;
			client.leard = "";
            for(var i=0;i<count;i++) {

                var name = '';
                while(1) {
                    var char = packet.readUInt16LE(packet.offset) || "An unnamed cell";
					  packet.offset += 2;
					
					
                   // if(char == 0) break;
                    client.leard += String.fromCharCode(char);
                }
             
            }

            if(JSON.stringify(client.leaders) == JSON.stringify(client.leard)) return;
            var old_leaders = client.leaders;
            client.leaders  = client.leard;

            if(client.debug >= 3)
                client.log('leaders update: ' + JSON.stringify(users));

            client.emitEvent('leaderBoardUpdate', old_leaders, users);
        },
				

                    '50': function(client, packet) {
						var packet = new Packet(packet);
                        var old = client.leardc;
                        client.leardc = "";
                        var padLength = packet.readUInt16LE(packet.offset, true);
                        var last = packet.readUInt8(packet.offset + 2, true);
                        packet.offset += 3;
                        /** @type {number} */
                        var i = 0;
                        for (; i < padLength; i++) {
                            var val = client.getString(packet);
                            client.leardc += val;
                        }

                        client.emitEvent('leaderBoardUpdate', old, client.leardc);

                    },
					
                    '64': function(client, packet) {
						var packet = new Packet(packet);
                        client.playerId = packet.readUInt16LE(packet.offset);
                        packet.offset += 2;
                        client.rainbow = packet.readUInt8(packet.offset++) == 1;
                        client.border = {};
                        client.border.left = packet.readUInt16LE(packet.offset, true);
                        packet.offset += 2;
                        client.border.top = packet.readUInt16LE(packet.offset, true);
                        packet.offset += 2;
                        client.border.right = packet.readUInt16LE(packet.offset, true);
                        packet.offset += 2;
                        client.border.bottom = packet.readUInt16LE(packet.offset, true);
                        packet.offset += 2;
                        /** @type {number} */
                        client.border.width = client.border.right - client.border.left;
                        /** @type {number} */
                        client.border.height = client.border.bottom - client.border.top;
							
                       /* if (client.item != null) {

                            
                            var buffer = new ArrayBuffer(1 + client.item.length + 1);
                            
                            var data = new DataView(buffer);
                            data.setUint8(0, 42);
                            client._insert(1, data, item);
							client.send(buffer);
                            client.item = null;
                        }*/

                    }
			
			



        };


    }

	getpacket(data , thisbot) {
		
		 let opcode = data[0];
		 
				if (thisbot.debug >= 4)
					console.log("New packet: " + opcode);
				
			
                let handler = thisbot.packetHandlers[opcode];


                if (handler) {
                    try {
						//var t = new Packet(data);
                        handler(thisbot, data);
						return true;
                    } catch (e) {
                        console.log(e);
                    }

                } else {

                    let data2 = data;
                    let opcode = data2.readUInt8(0);
                    var packet_id = opcode;
					if (thisbot.debug >= 4)
						console.log('Unhanded packet type:', packet_id, "Hex:", data[0]);
					return false;
		}
				
	}
	render(buffer) {
		for (;true;) {
		  var em = buffer.readUInt16LE(buffer.offset, true);
		  buffer.offset += 2;
		  if (em == 0) {
			break;
		  }
		}
	  }
    connect(server, agent) {
        console.log('Connecting to ' + server);
        let options = {
            agent: agent
        };
		console.log(options);
        this.ws = new WebSocket(server, null, options);

        this.ws.binnaryType = 'arraybuffer';

        this.ws.onopen = this._onOpen.bind(this);
		this.ws.onconnect = function (){
			
			       console.log('Socket Connected');
			
		}
        let thisbot = this;

        this.ws.on('message', function(data, flags) {
            if (flags.binary) {

               thisbot.getpacket(data, thisbot);

            }


        });


        this.ws.onclose = this._onClose.bind(this);

        this.ws.onerror = this._onError.bind(this);

        //this.authenticated = false;

    }

    disconnect() {
        if (this.ws) {
            this.ws.close();
        }
    }

	
	
	
    _onOpen() {

        /*let protocol_version = 5;

			var a;
            a = new Buffer(5);
            a.writeUInt8(254, 0);
            a.writeUInt32LE(5, 1, true);
            this._send(a);
			
            
			a = new Buffer(5);
            a.writeUInt8(255, 0);
            a.writeUInt32LE(154669603, 1);
            this._send(a);
			this.emit('connected');*/
			
			
			            var client = this;

            if (this.debug >= 1)
                console.log(this.client_name + ': Connected to server');

            this.inactive_interval = setInterval(this.detsroyInactive.bind(this), this.inactive_check);
            if (this.origin != "http://gota.io") {

                var buf = new Buffer(5);
                buf.writeUInt8(254, 0);
                buf.writeUInt32LE(5, 1);
                this._send(buf);

            } else {
                //First packet..
                var version = "0.9.8";
                var udataCur = "Gota Web " + version;
                var buffer = new Buffer(1 + udataCur.length + 1);
               
                buffer.writeUInt8(0, 255);
                this._insert(1, buffer, udataCur);
				
				
                this._send(data, true);

                //Second packet...

                /** @type {ArrayBuffer} */
                var data = new ArrayBuffer(1 + 6 + ("" + 1));
                /** @type {DataView} */
                var test = new DataView(data);
                test.setUint8(0, 10);
                test.setUint8(1, 0);
                test.setUint8(2, 255);
                test.setUint8(3, 255);
                test.setUint8(4, 0);
                test.setUint8(5, 0);
                test.setUint8(6, false ? 1 : 0);
                this._insert(7, test, "");
                this._send(data);

                //eh ? send ping wut ?

                if (this.isConnected()) {
                    /** @type {number} */
                    this.topLevelPrimitive = +new Date;
                    this._sendPing();
                }

                //They are unique :/


                if (!this.spectate) {
                    //Send name Xbots.io to server...
                    //var name = "χβσтѕ.ισ";
					var name = "xbots.io";
                    /** @type {ArrayBuffer} */
                    var buffer = new ArrayBuffer(1 + (name.length + 1) * 2);
                    /** @type {DataView} */
                    var view = new DataView(buffer);
                    view.setUint8(0, 0);
                    this.set(1, view, name);
                    this._send(view);
                } else {

                    /** @type {ArrayBuffer} */
                    var buffer = new ArrayBuffer(1);
                    /** @type {DataView} */
                    var view = new DataView(buffer);
                    view.setUint8(0, 1);
                    this._send(view);

                }
			
			}
    }

    _onClose() {
        console.log('Socket Closed');
        this.emit('disconnected');
    }

    _onError(e) {
        console.log('Socket error: ' + e);
    }

	moveTo() {
		
	}
	        read (buffer) {
            var str = "";
            for (; true;) {
                var b = buffer.readUInt16LE(buffer.offset, true);
                buffer.offset += 2;
                if (b == 0) {
                    break;
                }
                str += String.fromCharCode(b);
            }
            return str;
        }

        getString (buffer) {
            var str = "";
            for (; true;) {
                var b = packet.readUInt8(buffer.offset);
                buffer.offset++;
                if (b == 0) {
                    break;
                }
                str += String.fromCharCode(b);
            }
            return str;
        }
		        sendPing() {
            /** @type {ArrayBuffer} */
            var buffer = new ArrayBuffer(1);
            /** @type {DataView} */
            var view = new DataView(buffer);
            view.setUint8(0, 71);
            this._send(view);
        }
	
    emitEvent() {
        var args = [];
        for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
        try {
            this.emit.apply(this, args);
        } catch (e) {
            process.nextTick(function() {
                throw e;
            });
        }
    }
    _send(data) {
        if (!this.ws) {
            return console.log(('WebSocket is not initialized').red);
        } else {

        }
        console.log("Send data to server: ", data);
        this.ws.send(data);

    }

}
function Ball(client, id) {
    if(client.balls[id]) return client.balls[id];

    this.id    = id;
    this.name  = null;
    this.x     = 0;
    this.y     = 0;
    this.size  = 0;
    this.mass  = 0;
    this.virus = false;
    this.mine  = false;

    this.client      = client;
    this.destroyed   = false;
    this.visible     = false;
    this.last_update = (+new Date);
    this.update_tick = 0;

    client.balls[id] = this;
    return this;
}
Ball.prototype = {
    destroy: function(reason) {
        this.destroyed = reason;
        delete this.client.balls[this.id];
        var mine_ball_index = this.client.my_balls.indexOf(this.id);
        if(mine_ball_index > -1) {
            this.client.my_balls.splice(mine_ball_index, 1);
            this.client.emitEvent('mineBallDestroy', this.id, reason);
            if(!this.client.my_balls.length) this.client.emitEvent('lostMyBalls');
        }

        this.emitEvent('destroy', reason);
        this.client.emitEvent('ballDestroy', this.id, reason);
    },

    setCords: function(new_x, new_y) {
        if(this.x == new_x && this.y == new_y) return;
        var old_x = this.x;
        var old_y = this.y;
        this.x    = new_x;
        this.y    = new_y;

        if(!old_x && !old_y) return;
        this.emitEvent('move', old_x, old_y, new_x, new_y);
        this.client.emitEvent('ballMove', this.id, old_x, old_y, new_x, new_y);
    },

    setSize: function(new_size) {
        if(this.size == new_size) return;
        var old_size = this.size;
        this.size    = new_size;
        this.mass    = parseInt(Math.pow(new_size/10, 2));

        if(!old_size) return;
        this.emitEvent('resize', old_size, new_size);
        this.client.emitEvent('ballResize', this.id, old_size, new_size);
        if(this.mine) this.client.updateScore();
    },

    setName: function(name) {
        if(this.name == name) return;
        var old_name = this.name;
        this.name    = name;

        this.emitEvent('rename', old_name, name);
        this.client.emitEvent('ballRename', this.id, old_name, name);
    },

    update: function() {
        var old_time     = this.last_update;
        this.last_update = (+new Date);

        this.emitEvent('update', old_time, this.last_update);
        this.client.emitEvent('ballUpdate', this.id, old_time, this.last_update);
    },

    appear: function() {
        if(this.visible) return;
        this.visible = true;
        this.emitEvent('appear');
        this.client.emitEvent('ballAppear', this.id);

        if(this.mine) this.client.updateScore();
    },

    disappear: function() {
        if(!this.visible) return;
        this.visible = false;
        this.emitEvent('disappear');
        this.client.emitEvent('ballDisppear', this.id);
    },

    toString: function() {
        if(this.name) return this.id + '(' + this.name + ')';
        return this.id.toString();
    },

    // Fix https://github.com/pulviscriptor/alisio-client/issues/95
    emitEvent: function() {
        var args = [];
        for(var i=0;i<arguments.length;i++) args.push(arguments[i]);
        try {
            this.emit.apply(this, args);
        } catch(e) {
            process.nextTick(function() {
                throw e;
            });
        }
    }
};

// Inherit from EventEmitter
for (var key in EventEmitter.prototype) {
    if(!EventEmitter.prototype.hasOwnProperty(key)) continue;
    Client.prototype[key] = Ball.prototype[key] = EventEmitter.prototype[key];
}
module.exports = Client;