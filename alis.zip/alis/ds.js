// ==UserScript==
// @name        PolarsBots.tk - Client Script
// @namespace    PolarsBots.tk - Client Script
// @version      1.0
// @description  its da best
// @author       PolarsBots.tk - Client Script
// @match       *.CHiopvp.eu/*
// @match       *.CH.io/*
// @match       *.ogar.pw/*
// @match       *.154.16.127.140/*
// @match       *.cellcraft.io/*
// @match       *.CHios.com/*
// @match       *.CHz.com/*
// @match       *.mgar.io/*
// @match       *.CHiogame.club/*
// @match       *.old.ogarul.io/*
// @match       *.CHly.com/*
// @match       *.bubble.am/*
// @match       *.gota.io/*
// @match       *.CHiohub.net/*
// @match       *.CHserv.com/*
// @match       *.CHioservers.ga/*
// @match       *.cell.sh/*
// @match       *.alis.io/*
// @match       *.CHioplay.org/*
// @match       *.CHio.city/*
// @match       *.germs.io/*
// @match       *.CHioforums.io/*
// @match       *.CHiofun.com/*
// @match       *.CH.pro/*
// @match       *.CHabi.com/*
// @match       *.warball.co/*
// @match       *.CHiom.net/*
// @match       *.CH.re/*
// @match       *.CHpx.com/*
// @match       *.easyCHio.com/*
// @match       *.playCHio.org/*
// @match       *.CHiofr.com/*
// @match       *.CHio.xyz/*
// @match       *.CHios.org/*
// @match       *.CHiowun.com/*
// @match       *.usCH.com/*
// @match       *.CHioplay.com/*
// @match       *.privateCHio.net/*
// @match       *.CHiorage.com/*
// @match       *.blong.io/*
// @match       *.CH.blue/*
// @match       *.CH.bio/*
// @match       *.CHio.se/*
// @match       *.nbkio.com/*
// @match       *.CHiohit.com/*
// @match       *.CHiomultiplayer.com/*
// @match       *.CHiogameplay.com/*
// @match       *.CHiowow.com/*
// @match       *.bestCHio.net/*
// @match       *.tytio.com/*
// @match       *.kralCHio.com/*
// @match       *.CHio.zafer2.com/*
// @match       *.CHprivateserver.net/*
// @match       *.CHca.com/*
// @match       *.CHioplay.mobi/*
// @match       *.CHio.mobi*
// @match       *.abs0rb.me/*
// @match       *.CHio.us/*
// @match       *.CHiojoy.com/*
// @match       *.CHio.ch/*
// @match       *.ioCH.us/*
// @match       *.play.CHio0.com/*
// @match       *.CHio.run/*
// @match       *.CHpvp.us/*
// @match       *.CHio.pw/*
// @match       *.ogario.net/*
// @match       *.ogario.net/*
// @match       *.nbk.io/*
// @match       *.CHio.info/*
// @match       *.inciCHio.com/*
// @match       *.CH.io.biz.tr/*
// @match       *.CHiown.com/*
// @match       *.CHio.dk/*
// @match       *.CHio.lol/*
// @match       *.CHio.gen.tr/*
// @match       *.CHioprivateserver.us/*
// @match       *.CHiot.com/*
// @match       *.CHw.com/*
// @match       *.CHio.city/*
// @match       *.CHio.ovh/*
// @match       *.feedy.io/*
// @match       *.CH.zircon.at/*
// @match       *.xn--80aaiv4ak.xn--p1ai/*
// @require      https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.4.5/socket.io.min.js
// @grant        none
// @run-at       document-start
// ==/UserScript==

setTimeout(function() {
    window.__WebSocket = window.WebSocket;
    window.fakeWebSocket = function(){return {readyState: 0}};
    window._WebSocket = window.WebSocket = function(ip){return new window.fakeWebSocket(ip);};
    window.__botclonsData = {};
    window.__botclonsData.mx = 0;
    window.__botclonsData.my = 0;
    window.__botclonsData.ml = 0;
    window.__botclonsData.ma = 0;
    window.__botclonsData.mb = 0;
    window.__botclonsData.wa = false;
    window.__botclonsData.sa = false;
    window.__botclonsData.w = null;
    window.__botclonsData.s = null;
    window.__botclonsData.aX = -1;
    window.__botclonsData.aY = -1;
    window.__botclonsData.p = 0;
    window.__botclonsData.q=false;
    window.__botclonsData.socketaddr = null;
    var real_minx = -7071;
    var real_miny = -7071;
    var real_maxx = 7071;
    var real_maxy = 7071;
    var lastsent = {
        minx: 0,
        miny: 0,
        maxx: 0,
        maxy: 0
    };

    function valcompare(Y, Z) {
        return 0.01 > Y - Z && -0.01 < Y - Z
    }
    var socket = io.connect('ws://localhost:8081');
    var canMove = true;
    var movetoMouse = true;
    var moveEvent = new Array(2);
    var canvas = document.getElementById("canvas");
    last_transmited_game_server = null;
    socket.on('force-login', function(data) {
        socket.emit("login", {
            "uuid": client_uuid,
            "type": "client"
        });
        transmit_game_server()
    });
   
    $( "#canvas" ).after( "<div style='background-color: #000000; -moz-opacity: 0.4; -khtml-opacity: 0.4; opacity: 0.4; filter: alpha(opacity=40); zoom: 1; width: 205px; top: 10px; left: 10px; display: block; position: absolute; text-align: center; font-size: 15px; color: #ffffff; padding: 5px; font-family: Ubuntu;'> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><a>PolarsBots.tk</a></div> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><br>Bots: <a id='minionCount' >Offline</a> </div> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><br>Movement Offset: <a id='ismoveToMouse' >0</a> </div> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><br>Position: <a id='gh45nmvsy' >-</a> </div> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><br>Stop Movement: <a id='isStopMove' >Off</a> </div> <div style='color:#ffffff; display: inline; -moz-opacity:1; -khtml-opacity: 1; opacity:1; filter:alpha(opacity=100); padding: 10px;'><br>Chat Spam: <a id='dfdghehfj' >Off</a> </div>" );
   socket.on('spawn-count', function(data) {
        document.getElementById('minionCount').innerHTML = data
    });
    var client_uuid = localStorage.getItem('client_uuid');
    if (client_uuid == null) {
        console.log("generating a uuid for this user");
        client_uuid = ""; var ranStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var ii = 0; ii < 15; ii++) client_uuid += ranStr.charAt(Math.floor(Math.random() * ranStr.length));
        localStorage.setItem('client_uuid', client_uuid)
    }
    socket.emit("login", client_uuid);
    $("#instructions").replaceWith('<br><div class="input-group"><span class="input-group-addon" id="basic-addon1">UUID</span><input type="text" value="' + client_uuid + '" readonly class="form-control"</div>');

    function isMe(cell) {
        for (var i = 0; i < window.CH.myCells.length; i++) {
            if (window.CH.myCells[i] == cell.id) {
                return true
            }
        }
        return false
    }

    function getCell() {
        var me = [];
        for (var key in window.CH.allCells) {
            var cell = window.CH.allCells[key];
            if (isMe(cell)) {
                me.push(cell)
            }
        }
        return me[0]
    }
    var skin_var = 0;

    function emitPosition() {
        console.log(client_uuid);
        document.getElementById('gh45nmvsy').innerHTML=(~~(window.__botclonsData.mx-window.__botclonsData.ma))+","+(~~(window.__botclonsData.my-window.__botclonsData.mb));
        socket.emit("pos", {
            "x": window.__botclonsData.mx-window.__botclonsData.ma,
            "y": window.__botclonsData.my-window.__botclonsData.mb,
            "l": window.__botclonsData.ml,
            "p": window.__botclonsData.p,
            "c": window.__botclonsData.q
        })
    }

    function toggleMovement() {
        canMove = !canMove;
        switch (canMove) {
            case true:
                canvas.onmousemove = moveEvent[0];
                moveEvent[0] = null;
                canvas.onmousedown = moveEvent[1];
                moveEvent[1] = null;
                break;
            case false:
                canvas.onmousemove({
                    clientX: innerWidth / 2,
                    clientY: innerHeight / 2
                });
                moveEvent[0] = canvas.onmousemove;
                canvas.onmousemove = null;
                moveEvent[1] = canvas.onmousedown;
                canvas.onmousedown = null;
                break
        }
    }
    interval_id = setInterval(function() {
        emitPosition()
    }, 100);
    interval_id2 = setInterval(function() {
        transmit_game_server_if_changed()
    }, 5000);
    document.addEventListener('keydown', function(e) {
        var key = e.keyCode || e.which;
        switch (key) {
            case 16:
                if(!window.__botclonsData.sa){
                    window.__botclonsData.sa=true;
                window.__botclonsData.s = setInterval(function() {
$("body").trigger($.Event("keydown", { keyCode: 32}));
$("body").trigger($.Event("keyup", { keyCode: 32}));
}, 10);
                }
                break;
            case 87:
                if(!window.__botclonsData.wa){
                    window.__botclonsData.wa=true;
window.__botclonsData.w = setInterval(function() {
$("body").trigger($.Event("keydown", { keyCode: 87}));
$("body").trigger($.Event("keyup", { keyCode: 87}));
}, 10);
                }
                break;
                case 65:
                window.__botclonsData.p--;
                document.getElementById('ismoveToMouse').innerHTML = window.__botclonsData.p;
                break;
            case 67:
                window.__botclonsData.q=!window.__botclonsData.q;
                if(window.__botclonsData.q) { document.getElementById('dfdghehfj').innerHTML = "On"; } else { document.getElementById('dfdghehfj').innerHTML = "Off"; }
                break;
            case 69:
                socket.emit("cmd", {
            "name": "split"
        })
                break;
            case 82:
                socket.emit("cmd", {
            "name": "eject"
        })
                break;
            case 80:
                window.__botclonsData.p++;
                document.getElementById('ismoveToMouse').innerHTML = window.__botclonsData.p;
                break
        }
    });
    document.addEventListener('keyup', function(e) {
        var key = e.keyCode || e.which;
         console.log(key);
        switch (key) {
            case 87:
                clearInterval(window.__botclonsData.w);
                window.__botclonsData.wa=false;
                break;
            case 16:
                clearInterval(window.__botclonsData.s);
                window.__botclonsData.sa=false;
                break;
        }
    });

    function transmit_game_server_if_changed() {
        if (last_transmited_game_server != window.__botclonsData.socketaddr) {
            transmit_game_server()
        }
    }

    function transmit_game_server() {
        last_transmited_game_server = window.__botclonsData.socketaddr;
        socket.emit("cmd", {
            "name": "connect_server",
            "ip": window.__botclonsData.socketaddr,
            "origin": location.origin
        })
    }
    var mouseX = 0;
    var mouseY = 0;
    $("body").mousemove(function(event) {
        mouseX = event.clientX;
        mouseY = event.clientY
    });
}, 200)