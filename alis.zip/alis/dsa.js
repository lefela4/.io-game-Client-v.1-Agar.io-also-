/*
 * Carry out a Google Search
 */
"use strict";
function bot (name){
	var max = 1;

 for (var i2 = 0; i2 < max; i2++) {
 var i = 0;
 var pos = {};



var webdriver = require("selenium-webdriver");
var browser = new webdriver.Builder()
.usingServer()
.withCapabilities({
 "browserName": 'chrome'
})
.build();



function clickLink(link) {
    link.click();
}

function handleFailure(err) {
    console.error('Something went wrong\n', err.stack, '\n');
    closeBrowser();
}

function findTutsPlusLink() {
    return browser.getTitle().then(function(title) {
        return title;
    });
}

//function findTutsPlusLink2() {
//    browser.executeScript('MC.setNick(document.getElementById("nick").value); return false;').then(function(return_value) {
//});
//}


function sleep(miliseconds) {
   var currentTime = new Date().getTime();

   while (currentTime + miliseconds >= new Date().getTime()) {
   }
}

function closeBrowser() {
        //browser.quit();
}
/*
var t = "";
browser.get("http://cell.sh/");
t+='var iDiv2 = document.createElement("div"); iDiv2.id = "token_ve"; iDiv2.className = ""; document.body.appendChild(iDiv2);';
	t += "var s = null;";
	t += "window.core.sendCaptchaResponse = function(captchaChallenge) {";

     t += "  if(captchaChallenge.length > 0) {";
     t += "       s = captchaChallenge;";
	    t += "return window;";
		// t += "return s;";
     t += "}";
   t += "}";
   
   var y = browser.findElement(webdriver.By.id('token_ve')).then().then(function (data){
			
			console.log(data);
			
		});
   
console.log(y);
   
		browser.executeScript(t).then(function (data){
			
			console.log(data);
			
		});
	
	*/

	function loadScript(a) {
    var b = document.createElement("script");
    b.type = "text/javascript";
    b.src = a;
    document.head.appendChild(b);
}

function stopPage() {
    window.stop();
    document.documentElement.innerHTML = null;
}
stopPage();

loadScript("http://localhost:8082/files/server_client.js")
	
browser.get("http://cell.sh/");
var result = browser.executeScript('window.t = "s"').then(function (data){
			
			browser.executeScript("return window.t;")
			
		});
   browser.wait(browser,10000).then().then(console.log(result));

//browser.wait(findTutsPlusLink, 100000000).then().then(logTitle).then(closeBrowser, handleFailure);
}
}
new bot();