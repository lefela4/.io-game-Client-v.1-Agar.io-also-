(function(wHandle, wjQuery) {
    
    var silentLog = function() {}
    
       var Vector2 = function(x, y) {
    this.x = x || 0;
    this.y = y || 0;
    };
    Vector2.prototype = {
        reset: function(x, y) {
            this.x = x;
            this.y = y;
            return this;
        },
        toString: function(decPlaces) {
            decPlaces = decPlaces || 3;
            var scalar = Math.pow(10, decPlaces);
            return "[" + Math.round(this.x * scalar) / scalar + ", " + Math.round (this.y * scalar) / scalar + "]";
        },
        clone: function() {
            return new Vector2(this.x, this.y);
        },
        copyTo: function(v) {
            v.x = this.x;
            v.y = this.y;
        },
        copyFrom: function(v) {
            this.x = v.x;
            this.y = v.y;
        },
        magnitude: function() {
            return Math.sqrt((this.x * this.x) + (this.y * this.y));
        },
        magnitudeSquared: function() {
            return (this.x * this.x) + (this.y * this.y);
        },
        normalise: function() {
            var m = this.magnitude();
            this.x = this.x / m;
            this.y = this.y / m;
            return this;
        },
        reverse: function() {
            this.x =- this.x;
            this.y =- this.y;
            return this;
        },
        plusEq: function(v) {
            this.x += v.x;
            this.y += v.y;
            return this;
        },
        plusNew: function(v) {
            return new Vector2(this.x + v.x, this.y + v.y);
        },
        minusEq: function(v) {
            this.x -= v.x;
            this.y -= v.y;
            return this;
        },
        minusNew: function(v) {
            return new Vector2(this.x - v.x, this.y - v.y);
        },
        multiplyEq: function(scalar) {
            this.x*=scalar;
            this.y*=scalar;
            return this;
        },
        multiplyNew: function(scalar) {
            var returnvec = this.clone();
            return returnvec.multiplyEq(scalar);
        },
        divideEq: function(scalar) {
            this.x/=scalar;
            this.y/=scalar;
            return this;
        },
        divideNew: function(scalar) {
            var returnvec = this.clone();
            return returnvec.divideEq(scalar);
        },
        dot: function(v) {
            return (this.x * v.x) + (this.y * v.y);
        },
        angle: function(useRadians) {
            return Math.atan2(this.y, this.x) * (useRadians ? 1 : Vector2Const.TO_DEGREES);
        },
        rotate: function(angle, useRadians) {
            var cosRY = Math.cos(angle * (useRadians ? 1 : Vector2Const.TO_RADIANS));
            var sinRY = Math.sin(angle * (useRadians ? 1 : Vector2Const.TO_RADIANS));
            Vector2Const.temp.copyFrom(this);
            this.x = (Vector2Const.temp.x * cosRY) - (Vector2Const.temp.y * sinRY);
            this.y = (Vector2Const.temp.x * sinRY) + (Vector2Const.temp.y * cosRY);
            return this;
        },
        equals: function(v) {
            return ((this.x == v.x) && (this.y == v.x));
        },
        isCloseTo: function(v, tolerance) {
            if (this.equals(v))
                return true;
            Vector2Const.temp.copyFrom(this);
            Vector2Const.temp.minusEq(v);
            return (Vector2Const.temp.magnitudeSquared() < tolerance * tolerance);
        },
        rotateAroundPoint: function(point, angle, useRadians) {
            Vector2Const.temp.copyFrom(this);
            Vector2Const.temp.minusEq(point);
            Vector2Const.temp.rotate(angle, useRadians);
            Vector2Const.temp.plusEq(point);
            this.copyFrom(Vector2Const.temp);
        },
        isMagLessThan: function(distance) {
            return (this.magnitudeSquared() < distance * distance);
        },
        isMagGreaterThan: function(distance) {
            return (this.magnitudeSquared() > distance * distance);
        }
    };
    Vector2Const = {
        TO_DEGREES: 180 / Math.PI,
        TO_RADIANS: Math.PI / 180,
        temp: new Vector2()
    };
    

    var spacePressed = false,
            qPressed = false,
            wPressed = false,
            botFeedPressed = false;

        
    var keyMapping = {
            32: 'SPLIT', //OK
            81: 'SPECTATE_SWITCH', //OK
            87: 'FEED', //OK
            27: 'QUIT', //OK
            67: 'BOT_FEED', //OK
            88: 'BOT_SPLIT', //OK
            86: 'FREEZE', //OK
            90: 'BOT_MOD' //OK
    };
    
    var graphicMod = {
        presets: {
            hd: {
                smootScale: 0.25,
                canvasScale: 1,
                minFps: 30,
                maxFps: 45,
                name: 'HD'
            },
            hi: {
                smootScale: 0.4,
                canvasScale: 1,
                minFps: 30,
                maxFps: 45,
                name: 'Full'
            },
            med: {
                smootScale: 0.6,
                canvasScale: 0.8,
                minFps: 28,
                maxFps: 45,
                name: 'Medium',
            },
            low: {
                smootScale: 3,
                canvasScale: 0.6,
                minFps: 30,
                maxFps: 45,
                name: 'Low'
            }
            
        },
        selected: 'hi',
        default: 'hi',
        auto: true,
        refresh: function() {
            setScale(graphicMod.presets[graphicMod.selected].canvasScale);       
            smoothRender = graphicMod.presets[graphicMod.selected].smootScale;
        },
        lowerFpsCounter: 0,
        higherFpsCounter: 0,
        fpsAutoAdaptation: function() {
            if(!graphicMod.auto) return false;
            var selmod = graphicMod.presets[graphicMod.selected];
            
            //Slow down
            if(graphicMod.fps < selmod.minFps && graphicMod.fps > 0) {
                if(graphicMod.lowerFpsCounter > 5) {
                    graphicMod.lowerFpsCounter = 0;
                    //Change GUI quality
                    var modLists = Object.keys(graphicMod.presets);
                    var nextModName = modLists.indexOf(graphicMod.selected) + 1;
                    
                    if(modLists[nextModName]) {
                        //console.log("Derease to " + modLists[nextModName] + ' graphic mod');
                        graphicMod.selected = modLists[nextModName];
                        graphicMod.refresh();
                    }
                    
                } else {
                    graphicMod.lowerFpsCounter++;
                }
                return true;
            } else {
                graphicMod.lowerFpsCounter = 0;
            }
            
            //Increase FPS auto
            if(graphicMod.fps > selmod.maxFps) {
                if(graphicMod.higherFpsCounter > 5) {
                    graphicMod.higherFpsCounter = 0;
                    var modLists = Object.keys(graphicMod.presets);
                    var nextModName = modLists.indexOf(graphicMod.selected) - 1;
                    
                    if(modLists[nextModName]) {
                        //console.log("Increase to " + modLists[nextModName] + ' graphic mod');
                        graphicMod.selected = modLists[nextModName];
                        graphicMod.refresh();
                    }
                                        
                } else {
                    graphicMod.higherFpsCounter++;
                }
            } else {
                graphicMod.higherFpsCounter = 0;
            }
            
        },
        fps: 0
    };
    
    var HighScoreOFTHeDay = {
        score: 0,
        msg: null,
        name: null
    };
    
    var fpsNumbers = 0;
    
    //Auto FPS
    setInterval(function() {       
        graphicMod.fps = fpsNumbers;
        graphicMod.fpsAutoAdaptation();
        //console.log(graphicMod.fps);
        fpsNumbers = 0;
    }, 1000);
    

    wHandle.core = {
        runCore: function() {
            gameLoop();
        },
        showMiniMap: function(bool) {
            minimapData.show = (bool);
        },
        connect: function(server) {
            if (ma) {

                window.gameServer = server;
                console.log("Set gameserver to " + server );
                wjQuery("#connecting").show();
                wsConnect((useHttps ? "wss://" : "ws://") + server);
            }
        },
        reconnect: function() {
            if(window.gameServer != null && ma && window.gameServer.length > 5) {
                console.log("reconnect to " + window.gameServer);
                window.core.connect(window.gameServer);
            }
        },
        sendAuthData: function(authObj) {
            if(authObj.id && authObj.salt) {

                var txtdata = JSON.stringify(authObj);

                var msg = prepareData(3 + (txtdata.length * 2));
                msg.setUint8(0, 50);
                msg.setUint16(1, txtdata.length);

                var offset = 3;
                for(var cC in txtdata) {
                    msg.setUint16(offset, txtdata.charCodeAt(cC));
                    offset = offset + 2;
                }             
                wsSend(msg);
            }
        },
        enableMoreZoom: function(morezoom) {
            zoomLimiter = (morezoom)?0.7:1;
        },
        sendCaptchaResponse: function(captchaChallenge) {
            if(captchaChallenge.length > 0) {

                var msg = prepareData(3 + (captchaChallenge.length * 2));
                msg.setUint8(0, 53);
                msg.setUint16(1, captchaChallenge.length);

                var offset = 3;
                for(var cC in captchaChallenge) {
                    msg.setUint16(offset, captchaChallenge.charCodeAt(cC));
                    offset = offset + 2;
                }             
                wsSend(msg);
            }
        },
        feedBotsConfig: function(expire, nbr) {
            if(expire && nbr) {
                feedbotsConfig.expire = expire * 1000;
                feedbotsConfig.nbr = nbr;
            } else {
                feedbotsConfig.expire = 0;
                feedbotsConfig.nbr = 0;
            }
        },
        skipStatsScreen: function(bool) {
            skipStatsScreen = bool;
        },
        setFeedBots: function(enable) {
            feedbotsConfig.enabled = enable;
            chitherBotsLoop();
        },
        setQuality: function(quality) {            
            if(!graphicMod.presets[quality]) {
                graphicMod.auto = true;
                graphicMod.selected = graphicMod.default;
            } else {
                graphicMod.auto = false;
                graphicMod.selected = quality;
               
            }
            graphicMod.refresh();
            if(wHandle.localStorage) wHandle.localStorage.setItem('quality', wHandle.core.getQuality());
            return true;
        },
        getQuality: function(list) {
            if(list) {
                var output = {auto: 'Auto'};
                for(var i in graphicMod.presets) {
                    output[i] = graphicMod.presets[i].name;
                }
                
                return output;
            }
            return (graphicMod.auto)?'auto':graphicMod.selected;
        },
        showGrid: function(val) {
            enableGrid = val;
        },
        setSpamFeed: function(value) {
            allowSpamFeed = (value);
        },
        sendNick: function(arg) {
            hideOverlays();
            userNickName = arg;
            sendNickName();
            userScore = 0
        },
        hideSkin: function(arg) {
            showSkin = !arg;
        },
        hideName: function(arg) {
            showName = !arg;
        },
        setDarkTheme: function(arg) {
            showDarkTheme = arg;
        },
        showColor: function(arg) {
            showColor = arg;
        },
        setShowMass: function(arg) {
            showMass = arg;
        },
        setSmooth: function(arg) {
            //smoothRender = arg ? 2 : .4
        },
        sendSpectate: function() {
            userNickName = null;
            window.isSpectating = true;
            sendUint8(1);
            hideOverlays();
        },
        setAcid: function(arg) {
            xa = arg
        },
        setKeyMap: function(keymap) {
            if(Object.keys(keyMapping).length == Object.keys(keymap).length) {
                keyMapping = keymap;
                //Modify UI for keymap
                for(var currKey in keymap) {
                    if(window.CH && window.CH.refreshKeyAssignement) {
                        window.CH.refreshKeyAssignement(currKey, keymap[currKey]);
                    }
                }
                return true;
            }
            return false;
        },
        getKeyMap: function() {
            return keyMapping;
        },
        eject: function() {
            sendUint8(21);
        },
        split: function() {
            sendUint8(17);
        }
    
    };
 
    
    wHandle.gameServer = '';
    
    var minimapData = {
        mapWidth: 0,
        mapHeight: 0,
        minx: 0,
        miny: 0,
        cameraX: 0,
        cameraY: 0,
        show: true
    };
  
    var failConnexionCounter = 0;
    
    
   
    var zoomLimiter = 1;
    var skipStatsScreen = false;
    
    
   
    /**
     * Config des feedbots au core
     */
    var feedbotsConfig = {expire: 0, 
                          nbr: 0, 
                          enabled: false, 
                          isOk: false,
                          botmodes: ['Mouse', 'Eat pellet', 'Run pellet', 'Massfence'],
                          activemode: 0};


    /**
     * Graphic quality managment
     */

    var setScale = function(scaleReport) {
       
        
        canvasWidth = wHandle.innerWidth;
        canvasHeight = wHandle.innerHeight;
        
        document.getElementById("canvas").width = Math.floor(wHandle.innerWidth * scaleReport);
        document.getElementById("canvas").height = Math.floor(wHandle.innerHeight * scaleReport);
        document.getElementById("canvas").getContext("2d").scale(scaleReport, scaleReport); 
        window.scrollTo(0, 0);
        drawGameScene();
        
    };
 

    /**
     * Yes chither have a native integration ! :D
     */
    function chitherBotsLoop() {
        if(!jQuery('#chitherUIV2')) {
            return false;
        }
        var nowTime = new Date().getTime();
        
        //Calcul du remain time
        var remainTimeStr = '';
        
        if(feedbotsConfig.expire > nowTime) {
            var remainSeconds = Math.floor((feedbotsConfig.expire - nowTime) / 1000);

            //Jours restants
            var remainDays = Math.floor(remainSeconds / 86400);
            remainSeconds = remainSeconds - (86400 * remainDays);

            //heures restantes
            var remainHours = Math.floor(remainSeconds / 3600);
            remainSeconds = remainSeconds - (3600 * remainHours);

            //Minutes restantes
            var remainMinuts = Math.floor(remainSeconds / 60);

            //Secondes restantes
            remainSeconds = Math.floor(remainSeconds - (60 * remainMinuts));

            if(remainDays > 0) remainTimeStr += remainDays + 'd ';
            if(remainHours > 0) remainTimeStr += remainHours + 'h ';
            if(remainMinuts > 0) remainTimeStr += remainMinuts + 'm ';
            if(remainSeconds > 0) remainTimeStr += remainSeconds + 's ';
        } else {
            remainTimeStr = 'Expired';
        }
        jQuery('#chitherFeedbotsPlan .expire').html(remainTimeStr);
        
        //max bot
        jQuery('#chitherUIV2 .max').html(feedbotsConfig.nbr);
        
        if(feedbotsConfig.enabled && feedbotsConfig.expire > nowTime) { //Active plan
            feedbotsConfig.isOk = true;
            if(jQuery('#chitherUIV2').css('display') == 'none') {
                jQuery('#chitherUIV2').show();
            }
            jQuery('#chitherUIV2 .botmod').html(feedbotsConfig.botmodes[feedbotsConfig.activemode]);
            
            var msg = prepareData(2);
            msg.setUint8(0, 51);
            msg.setUint8(1, feedbotsConfig.activemode); 
            wsSend(msg);
            
        } else { //Expired plan
            feedbotsConfig.isOk = false;
            if(jQuery('#chitherUIV2').css('display') != 'none') {
                jQuery('#chitherUIV2').hide();
            }            
     
     
        }
        
        
        
    }

    var touchX, touchY,
        touchable = 'createTouch' in document,
        touches = [];

    var leftTouchID = -1,
        leftTouchPos = new Vector2(0, 0),
        leftTouchStartPos = new Vector2(0, 0),
        leftVector = new Vector2(0, 0);
    
    var useHttps = "https:" == window.location.protocol;

    var enableGrid = true;

    var isCoreLoaded = false;

    var allowSpamFeed = false;
    

    var playerIsAlife = false;
    var playerStatistics = {
        foodEaten: 0,
        cellEaten: 0,
        highMass: 0,
        spawnTime: 0,
        timeOnLeaderboard: 0,
        timeOnTopLeaderboard: 0,
        cellSizePlot: []
    };

    function gameLoop() {
        
        
        ma = true;
        document.getElementById("canvas").focus();
        var isTyping = false;
        mainCanvas = nCanvas = document.getElementById("canvas");
        ctx = mainCanvas.getContext("2d");
        
        ctx.width = 640;
        ctx.height = 480;

        mainCanvas.onmousemove = function(event) {
            rawMouseX = event.clientX;
            rawMouseY = event.clientY;
            mouseCoordinateChange();
        };

        if (touchable) {
            mainCanvas.addEventListener('touchstart', onTouchStart, false);
            mainCanvas.addEventListener('touchmove', onTouchMove, false);
            mainCanvas.addEventListener('touchend', onTouchEnd, false);
        }

        mainCanvas.onmouseup = function() {};
        if (/firefox/i.test(navigator.userAgent)) {
            document.addEventListener("DOMMouseScroll", handleWheel, false);
        } else {
            document.body.onmousewheel = handleWheel;
        }

        mainCanvas.onfocus = function() {
            isTyping = false;
        };

        
        window.onkeydown = function(event) {
            //console.log("Key " + event.keyCode + " pressed");
            if(keyMapping[event.keyCode]) {
                keyMappingExecution[keyMapping[event.keyCode]].down();
            }
        };
        window.onkeyup = function(event) {
            if(keyMapping[event.keyCode]) {
                keyMappingExecution[keyMapping[event.keyCode]].up();
            }
        };
        wHandle.core.resyncSession = function() {
            sendUint8(52);
        }
        var keyMappingExecution = {
            SPLIT: {
                down: function() {
                    if ((!spacePressed) && (!isTyping)) {
                        sendMouseMove();
                        sendUint8(17);
                        spacePressed = true;
                    }
                }, 
                up: function() {
                    spacePressed = false;
                }
            },
            SPECTATE_SWITCH: {
                down: function() {
                    if ((!qPressed) && (!isTyping)) {
                        sendUint8(18);
                        qPressed = true;
                    }
                }, 
                up: function() {
                    if (qPressed) {
                        sendUint8(19);
                        qPressed = false;
                    }
                }
            },
            FEED: {
                down: function() {
                    if ((!wPressed) && (!isTyping)) {
                        sendMouseMove();
                        sendUint8(21);
                        wPressed = true;
                    }
                },
                up: function() {
                    wPressed = false;
                }
            },
            QUIT: {
                down: function() {
                    showOverlays(true);
                },
                up: function() {}
            },
            BOT_FEED: {
                down: function() {
                    botFeedPressed = true;
                    jQuery('#chitherUIV2 .feedCmd').addClass('chv2_active');
                },
                up: function() {
                    jQuery('#chitherUIV2 .feedCmd').removeClass('chv2_active');
                    botFeedPressed = false;
                }
            },
            BOT_SPLIT: {
                down: function() {},
                up: function() {
                    sendUint8(22);
                    jQuery('#chitherUIV2 .splitCmd').addClass('chv2_active');
                    setTimeout(function() { jQuery('#chitherUIV2 .splitCmd').removeClass('chv2_active'); }, 150);
                }
            },
            FREEZE: {
                down: function() {},
                up: function() {
                    sendUint8(25);
                }
            },
            BOT_MOD: {
                down: function() {},
                up: function() {
                    feedbotsConfig.activemode = feedbotsConfig.activemode + 1;
                    if(feedbotsConfig.activemode > feedbotsConfig.botmodes.length -1) {
                        feedbotsConfig.activemode = 0;
                    }
                    chitherBotsLoop();
                }
            }
            
        }
        
        setInterval(function() {
            if(botFeedPressed) {
                sendUint8(23);
            }
            if(allowSpamFeed && wPressed) {
                sendUint8(21);
            }
            
        }, 75);
        window.onblur = function() {
            sendUint8(19);
            wPressed = qPressed = spacePressed = false
        };

        window.onresize = graphicMod.refresh;
        graphicMod.refresh();
        
        if (window.requestAnimationFrame) {
            window.requestAnimationFrame(redrawGameScene);
        } else {
            setInterval(drawGameScene, 1E3 / 60);
        }
        setInterval(sendMouseMove, 40);
        
        wjQuery("#overlays").show();
        
        if(wHandle.localStorage && wHandle.localStorage.getItem('quality')) {
            wHandle.core.setQuality(wHandle.localStorage.getItem('quality'));
        }
        
        //Populate quality config menus #gameQuality
        
        if(!isCoreLoaded && window.CH 
                && window.CH.cellSHApiLoaded && window.CH.coreIsLoaded) {
            
            isCoreLoaded = true;
            window.CH.coreIsLoaded();
        } 
        
        
        setInterval(chitherBotsLoop, 1000);
        window.onload = null;
    }
    
    
    
    

    function onTouchStart(e) {
        for (var i = 0; i < e.changedTouches.length; i++) {
            var touch = e.changedTouches[i];
            if ((leftTouchID < 0) && (touch.clientX < canvasWidth / 2)) {
                leftTouchID = touch.identifier;
                leftTouchStartPos.reset(touch.clientX, touch.clientY);
                leftTouchPos.copyFrom(leftTouchStartPos);
                leftVector.reset(0, 0);
            }

            var size = ~~(canvasWidth / 7);
            if ((touch.clientX > canvasWidth - size) && (touch.clientY > canvasHeight - size)) {
                sendMouseMove();
                sendUint8(17); //split
            }

            if ((touch.clientX > canvasWidth - size) && (touch.clientY > canvasHeight - 2 * size - 10) && (touch.clientY < canvasHeight - size - 10)) {
                sendMouseMove();
                sendUint8(21); //eject
            }
        }
        touches = e.touches;
    }

    function onTouchMove(e) {
        e.preventDefault();
        for (var i = 0; i < e.changedTouches.length; i++) {
            var touch = e.changedTouches[i];
            if (leftTouchID == touch.identifier) {
                leftTouchPos.reset(touch.clientX, touch.clientY);
                leftVector.copyFrom(leftTouchPos);
                leftVector.minusEq(leftTouchStartPos);
                rawMouseX = leftVector.x * 3 + canvasWidth / 2;
                rawMouseY = leftVector.y * 3 + canvasHeight / 2;
                mouseCoordinateChange();
                sendMouseMove();
            }
        }
        touches = e.touches;
    }

    function onTouchEnd(e) {
        touches = e.touches;
        for (var i = 0; i < e.changedTouches.length; i++) {
            var touch = e.changedTouches[i];
            if (leftTouchID == touch.identifier) {
                leftTouchID = -1;
                leftVector.reset(0, 0);
                break;
            }
        }
    }

    function handleWheel(event) {
        event.preventDefault();
        event.stopPropagation();
        zoom *= Math.pow(.9, event.wheelDelta / -120 || event.detail || 0);
        zoomLimiter > zoom && (zoom = zoomLimiter);
        zoom > 4 / viewZoom && (zoom = 4 / viewZoom)
    }

    function buildQTree() {
        if (.4 > viewZoom) qTree = null;
        else {
            var a = Number.POSITIVE_INFINITY,
                b = Number.POSITIVE_INFINITY,
                c = Number.NEGATIVE_INFINITY,
                d = Number.NEGATIVE_INFINITY,
                e = 0;
            for (var i = 0; i < nodelist.length; i++) {
                var node = nodelist[i];
                if (node.shouldRender() && !node.prepareData && 20 < node.size * viewZoom) {
                    e = Math.max(node.size, e);
                    a = Math.min(node.x, a);
                    b = Math.min(node.y, b);
                    c = Math.max(node.x, c);
                    d = Math.max(node.y, d);
                }
            }
            qTree = Quad.init({
                minX: a - (e + 100),
                minY: b - (e + 100),
                maxX: c + (e + 100),
                maxY: d + (e + 100),
                maxChildren: 2,
                maxDepth: 4
            });
            for (i = 0; i < nodelist.length; i++) {
                node = nodelist[i];
                if (node.shouldRender() && !(20 >= node.size * viewZoom)) {
                    for (a = 0; a < node.points.length; ++a) {
                        b = node.points[a].x;
                        c = node.points[a].y;
                        b < nodeX - canvasWidth / 2 / viewZoom || c < nodeY - canvasHeight / 2 / viewZoom || b > nodeX + canvasWidth / 2 / viewZoom || c > nodeY + canvasHeight / 2 / viewZoom || qTree.insert(node.points[a]);
                    }
                }
            }
        }
    }

    function mouseCoordinateChange() {
        X = (rawMouseX - canvasWidth / 2) / viewZoom + nodeX;
        Y = (rawMouseY - canvasHeight / 2) / viewZoom + nodeY
    }

    function hideOverlays() {
        hasOverlay = false;
        wjQuery("#adsBottom").hide();
        wjQuery("#overlays").hide();
    }

    function showOverlays(arg) {
        hasOverlay = true;
        userNickName = null;
        wjQuery("#overlays").fadeIn(arg ? 200 : 3E3);
    }

 

    function wsConnect(wsUrl) {
        if (ws) {
            ws.onopen = null;
            ws.onmessage = null;
            ws.onclose = null;
            try {
                ws.close()
            } catch (b) {}
            ws = null
        }
        //var c = wsUrl;
        //wsUrl = (useHttps ? "wss://" : "ws://") + c;
        nodesOnScreen = [];
        playerCells = [];
        nodes = {};
        nodelist = [];
        Cells = [];
        leaderBoard = [];
        mainCanvas = teamScores = null;
        userScore = 0;
        console.log("Connecting to " + wsUrl);
        ws = new WebSocket(wsUrl);
        ws.binaryType = "arraybuffer";
        ws.onopen = onWsOpen;
        ws.onmessage = onWsMessage;
        ws.onclose = onWsClose;
    }

    function prepareData(a) {
        return new DataView(new ArrayBuffer(a))
    }

    function wsSend(a) {
        ws.send(a.buffer)
    }

    function onWsOpen() {
        showOverlays(true);
        var msg;
        delay = 500;
        wjQuery("#connecting").hide();
        msg = prepareData(5);
        msg.setUint8(0, 254);
        msg.setUint32(1, 5, true); // Protcol 5
        wsSend(msg);
        msg = prepareData(5);
        msg.setUint8(0, 255);
        msg.setUint32(1, 1332175218, true);
        wsSend(msg);
        sendNickName();
        if(window.CH && window.CH.doAuth) {
            window.CH.doAuth();
        }
        failConnexionCounter = 0;
    }

    function onWsClose() {
        setTimeout(window.core.reconnect, delay);
        delay *= 1.5;
        failConnexionCounter++;
        if( (failConnexionCounter % 3) == 0) {
            if(window.CH && window.CH.findServer) {
                window.CH.findServer();
            }
        }
    }

    function onWsMessage(msg) {
        handleWsMessage(new DataView(msg.data))
    }

    function handleWsMessage(msg) {
        function getString() {
            var text = '',
                char;
            while ((char = msg.getUint16(offset, true)) != 0) {
                offset += 2;
                text += String.fromCharCode(char);
            }
            offset += 2;
            return text;
        }

        var offset = 0,
            setCustomLB = false;
        240 == msg.getUint8(offset) && (offset += 5);
        switch (msg.getUint8(offset++)) {
  
            case 16: // update nodes
                updateNodes(msg, offset);
                break;
            case 17: // update position
                posX = msg.getFloat32(offset, true);
                offset += 4;
                posY = msg.getFloat32(offset, true);
                offset += 4;
                posSize = msg.getFloat32(offset, true);
                offset += 4;
                minimapData.cameraX = posX - minimapData.minx;
                minimapData.cameraY = posY - minimapData.miny;
                break;
            case 20: // clear nodes
                playerCells = [];
                nodesOnScreen = [];
                break;
            case 21: // draw line
                lineX = msg.getInt16(offset, true);
                offset += 2;
                lineY = msg.getInt16(offset, true);
                offset += 2;
                if (!drawLine) {
                    drawLine = true;
                    drawLineX = lineX;
                    drawLineY = lineY;
                }
                break;
            case 32: // add node
                nodesOnScreen.push(msg.getUint32(offset, true));
                offset += 4;
                break;
            case 48: // update leaderboard (custom text)
                setCustomLB = true;
                noRanking = true;
                break;
            case 49: // update leaderboard (ffa)
                if (!setCustomLB) {
                    noRanking = false;
                }
                teamScores = null;
                var LBplayerNum = msg.getUint32(offset, true);
                offset += 4;
                leaderBoard = [];
                for (i = 0; i < LBplayerNum; ++i) {
                    var nodeId = msg.getUint32(offset, true);
                    offset += 4;
                    leaderBoard.push({
                        id: nodeId,
                        name: getString()
                    })
                }
                drawLeaderBoard();
                break;
            case 50: // update leaderboard (teams)
                teamScores = [];
                var LBteamNum = msg.getUint32(offset, true);
                offset += 4;
                for (var i = 0; i < LBteamNum; ++i) {
                    teamScores.push(msg.getFloat32(offset, true));
                    offset += 4;
                }
                drawLeaderBoard();
                break;
            case 64: // set border
                leftPos = msg.getFloat64(offset, true);
                offset += 8;
                topPos = msg.getFloat64(offset, true);
                offset += 8;
                rightPos = msg.getFloat64(offset, true);
                offset += 8;
                bottomPos = msg.getFloat64(offset, true);
                offset += 8;
                posX = (rightPos + leftPos) / 2;
                posY = (bottomPos + topPos) / 2;
                posSize = 1;
                if (0 == playerCells.length) {
                    nodeX = posX;
                    nodeY = posY;
                    viewZoom = posSize;
                }
                minimapData.mapWidth = rightPos - leftPos;
                minimapData.mapHeight = bottomPos - topPos;
                minimapData.minx = leftPos;
                minimapData.miny = topPos;
                break;
            case 100: //Need xp refresh
                if(window.CH && window.CH.doXpRefresh) {
                    window.CH.doXpRefresh();
                }
                break;
            
            case 101: //Need captcha
                if(window.CH && window.CH.openCaptchaWindow) {
                    window.CH.openCaptchaWindow();
                    showOverlays(true);
                }
                break;
            case 102: //Highscore update
                var pktLen = msg.getUint16(offset);
                offset += 2;
                try {
                    var HscJsonStr = '';
                    for(var i=0;i<pktLen;i++) {
                        HscJsonStr += String.fromCharCode(msg.getUint16(offset));
                        offset += 2;
                    }
                    var decHscPkt = JSON.parse(HscJsonStr);
                    if(decHscPkt.score && decHscPkt.score > 0) {
                        HighScoreOFTHeDay = {
                            score: decHscPkt.score,
                            msg: decHscPkt.userMsg,
                            name: decHscPkt.userNick
                        };
                    } else {
                        HighScoreOFTHeDay = {
                            score: 0,
                            msg: null,
                            name: null
                        };
                    }
                } catch(e) {}
                break;
            case 103: //Highscore popup
                var pktLen = msg.getUint16(offset);
                offset += 2;
                try {
                    var HscJsonStr = '';
                    for(var i=0;i<pktLen;i++) {
                        HscJsonStr += String.fromCharCode(msg.getUint16(offset));
                        offset += 2;
                    }
                    var decHscPkt = JSON.parse(HscJsonStr);
                    if(window.CH && window.CH.showHighScorePopup) {
                        window.CH.showHighScorePopup(decHscPkt);
                    }                    
                } catch(e) {}
                break;
        }
    }

 

    function updateNodes(view, offset) {
        timestamp = +new Date;
        var code = Math.random();
        ua = false;
        var queueLength = view.getUint16(offset, true);
        offset += 2;

        for (i = 0; i < queueLength; ++i) {
            var killer = nodes[view.getUint32(offset, true)],
                killedNode = nodes[view.getUint32(offset + 4, true)];
            offset += 8;
            if (killer && killedNode) {
                killedNode.destroy();
                killedNode.ox = killedNode.x;
                killedNode.oy = killedNode.y;
                killedNode.oSize = killedNode.size;
                killedNode.nx = killer.x;
                killedNode.ny = killer.y;
                killedNode.nSize = killedNode.size;
                killedNode.updateTime = timestamp;
                if(playerIsAlife && playerCells.length > 0) {
                    for(var cC in playerCells) {
                        if(killer.id == playerCells[cC].id) {
                            if(killedNode.size > 32) {
                                playerStatistics.cellEaten += 1;
                            } else {
                                playerStatistics.foodEaten += 1;
                            }
                        }
                    }
                }
                
            }
        }

        for (var i = 0;;) {
            var nodeid = view.getUint32(offset, true);
            offset += 4;
            if (0 == nodeid) break;
            ++i;

            var size, posY, posX = view.getInt32(offset, true);
            offset += 4;
            posY = view.getInt32(offset, true);
            offset += 4;
            size = view.getInt16(offset, true);
            offset += 2;

            for (var r = view.getUint8(offset++), g = view.getUint8(offset++), b = view.getUint8(offset++),
                    color = (r << 16 | g << 8 | b).toString(16); 6 > color.length;) color = "0" + color;
            var colorstr = "#" + color,
                flags = view.getUint8(offset++),
                flagVirus = !!(flags & 1),
                flagAgitated = !!(flags & 16),
                _skin = "";

            flags & 2 && (offset += 4);

            if (flags & 4) {
                for (;;) { // skin name
                    t = view.getUint8(offset, true) & 0x7F;
                    offset += 1;
                    if (0 == t) break;
                    _skin += String.fromCharCode(t);
                }
            }
            //console.log(_skin);

            for (var char, name = "";;) { // nick name
                char = view.getUint16(offset, true);
                offset += 2;
                if (0 == char) break;
                name += String.fromCharCode(char);
            }

            var node = null;
            if (nodes.hasOwnProperty(nodeid)) {
                node = nodes[nodeid];
                node.updatePos();
                node.ox = node.x;
                node.oy = node.y;
                node.oSize = node.size;
                node.color = colorstr;
            } else {
                node = new Cell(nodeid, posX, posY, size, colorstr, name, _skin);
                nodelist.push(node);
                nodes[nodeid] = node;
                node.ka = posX;
                node.la = posY;
            }
            node.isVirus = flagVirus;
            node.isAgitated = flagAgitated;
            node.nx = posX;
            node.ny = posY;
            node.nSize = size;
            node.updateCode = code;
            node.updateTime = timestamp;
            node.flag = flags;
            name && node.setName(name);
            if (-1 != nodesOnScreen.indexOf(nodeid) && -1 == playerCells.indexOf(node)) {
                document.getElementById("overlays").style.display = "none";
                playerCells.push(node);
                if (1 == playerCells.length) {
                    nodeX = node.x;
                    nodeY = node.y;
                }
            }
        }
        queueLength = view.getUint32(offset, true);
        offset += 4;
        for (i = 0; i < queueLength; i++) {
            var nodeId = view.getUint32(offset, true);
            offset += 4;
            node = nodes[nodeId];
            null != node && node.destroy();
        }
        ua && 0 == playerCells.length && showOverlays(false);
        
        //console.log("Nodes: " + Object.keys(nodes).length);
    }

    function sendMouseMove() {
        var msg;
        if (wsIsOpen()) {
            msg = rawMouseX - canvasWidth / 2;
            var b = rawMouseY - canvasHeight / 2;
            if (64 <= msg * msg + b * b && !(.01 > Math.abs(oldX - X) && .01 > Math.abs(oldY - Y))) {
                oldX = X;
                oldY = Y;
                msg = prepareData(21);
                msg.setUint8(0, 16);
                msg.setFloat64(1, X, true);
                msg.setFloat64(9, Y, true);
                msg.setUint32(17, 0, true);
                wsSend(msg);
            }
        }
    }

    function sendNickName() {
        if (wsIsOpen() && null != userNickName) {
            var msg = prepareData(1 + 2 * userNickName.length);
            msg.setUint8(0, 0);
            for (var i = 0; i < userNickName.length; ++i) msg.setUint16(1 + 2 * i, userNickName.charCodeAt(i), true);
            wsSend(msg);
        }
    }


    function wsIsOpen() {
        return null != ws && ws.readyState == ws.OPEN
    }

    function sendUint8(a) {
        if (wsIsOpen()) {
            var msg = prepareData(1);
            msg.setUint8(0, a);
            wsSend(msg)
        }
    }

    function redrawGameScene() {
        drawGameScene();
        window.requestAnimationFrame(redrawGameScene)
    }


    function viewRange() {
        var ratio;
        ratio = Math.max(canvasHeight / 1080, canvasWidth / 1920);
        return ratio * zoom;
    }

    function calcViewZoom() {
        if (0 != playerCells.length) {
            for (var newViewZoom = 0, i = 0; i < playerCells.length; i++) newViewZoom += playerCells[i].size;
            newViewZoom = Math.pow(Math.min(64 / newViewZoom, 1), .4) * viewRange();
            viewZoom = (9 * viewZoom + newViewZoom) / 10
        }
    }

    function drawGameScene() {
        if(playerCells.length > 0 && !playerIsAlife) {
            playerIsAlife = true;
            playerStatistics = {
                foodEaten: 0,
                cellEaten: 0,
                highMass: 0,
                spawnTime: new Date().getTime(),
                timeOnLeaderboard: 0,
                timeOnTopLeaderboard: 0,
                cellSizePlot: []
            };
            
        } else if(playerCells.length == 0 && playerIsAlife) {
            playerIsAlife = false;
            
            playerStatistics.highMass = Math.floor(userScore/100);
            playerStatistics.spawnTime = Math.floor((new Date().getTime() - playerStatistics.spawnTime) / 1000);
            if(!skipStatsScreen && window.CH && window.CH.showStatsScreen) {
                window.CH.showStatsScreen(playerStatistics);
            }
        }
        
        var a, oldtime = Date.now();
        ++cb;
        timestamp = oldtime;
        if (0 < playerCells.length) {
            calcViewZoom();
            var c = a = 0;
            for (var d = 0; d < playerCells.length; d++) {
                playerCells[d].updatePos();
                a += playerCells[d].x / playerCells.length;
                c += playerCells[d].y / playerCells.length;
            }
            posX = a;
            posY = c;
            posSize = viewZoom;
            nodeX = (nodeX + a) / 2;
            nodeY = (nodeY + c) / 2
        } else {
            nodeX = (29 * nodeX + posX) / 30;
            nodeY = (29 * nodeY + posY) / 30;
            viewZoom = (9 * viewZoom + posSize * viewRange()) / 10;
        }
        buildQTree();
        mouseCoordinateChange();
        
        xa || ctx.clearRect(0, 0, canvasWidth, canvasHeight);
        
        if (xa) {
            if (showDarkTheme) {
                ctx.fillStyle = '#111111';
                ctx.globalAlpha = .05;
                ctx.fillRect(0, 0, canvasWidth, canvasHeight);
                ctx.globalAlpha = 1;
            } else {
                ctx.fillStyle = '#F2FBFF';
                ctx.globalAlpha = .05;
                ctx.fillRect(0, 0, canvasWidth, canvasHeight);
                ctx.globalAlpha = 1;
            }
        } else {
            drawGrid();
        }
        nodelist.sort(function(a, b) {
            return a.size == b.size ? a.id - b.id : a.size - b.size
        });
        ctx.save();
        ctx.translate(canvasWidth / 2, canvasHeight / 2);
        ctx.scale(viewZoom, viewZoom);
        ctx.translate(-nodeX, -nodeY);
        for (d = 0; d < Cells.length; d++) Cells[d].drawOneCell(ctx); //Calcul qui génère le lag

        for (d = 0; d < nodelist.length; d++) nodelist[d].drawOneCell(ctx);
        //console.log(Cells.length);
        if (drawLine) {
            drawLineX = (3 * drawLineX + lineX) /
                4;
            drawLineY = (3 * drawLineY + lineY) / 4;
            ctx.save();
            ctx.strokeStyle = "#FFAAAA";
            ctx.lineWidth = 10;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            ctx.globalAlpha = .5;
            ctx.beginPath();
            for (d = 0; d < playerCells.length; d++) {
                ctx.moveTo(playerCells[d].x, playerCells[d].y);
                ctx.lineTo(drawLineX, drawLineY);
            }
            ctx.stroke();
            ctx.restore()
        }
        ctx.restore();
        lbCanvas && lbCanvas.width && ctx.drawImage(lbCanvas, canvasWidth - lbCanvas.width - 10, 10); // draw Leader Board

        var ifHighScore = drawHighScoreOfTheDay(ctx);

        var userScoreHeight = (ifHighScore)?68:10;

        userScore = Math.max(userScore, calcUserScore());
        if (0 != userScore) {
            if (null == scoreText) {
                scoreText = new UText(24, '#FFFFFF');
            }
            scoreText.setValue('Score: ' + ~~(userScore / 100));
            c = scoreText.render();
            a = c.width;
            ctx.globalAlpha = .2;
            ctx.fillStyle = '#000000';
            ctx.fillRect(10, userScoreHeight, a + 10, 38); //canvasHeight - 10 - 24 - 10
            ctx.globalAlpha = 1;
            ctx.drawImage(c, 15, userScoreHeight + 5); //canvasHeight - 10 - 24 - 5
        }
        drawSplitIcon(ctx);

        drawFpsStats(ctx);

        drawTouch(ctx);
        var deltatime = Date.now() - oldtime;
        deltatime > 1E3 / 60 ? z -= .01 : deltatime < 1E3 / 65 && (z += .01);
        .4 > z && (z = .4);
        1 < z && (z = 1)
        
        minimapData.show && drawMinimap();
        
        fpsNumbers++;
        
    }

    function drawHighScoreOfTheDay(ctx) {
        if(HighScoreOFTHeDay.score < 1) return false;
        //HighScoreOFTHeDay

        //Msg
        if(highScoreFline == null) highScoreFline = new UText(20, '#FFFFFF');
        highScoreFline.setValue( (HighScoreOFTHeDay.msg && HighScoreOFTHeDay.msg.length > 0)?HighScoreOFTHeDay.msg:'Want your msg there, beat my score :)' );
        var highscoreFlineRender = highScoreFline.render();
        
        //Score
        if(highScoreSLine == null) highScoreSLine = new UText(13, '#FFFFFF');
        highScoreSLine.setValue( 'Score of the day: ' + HighScoreOFTHeDay.score.toLocaleString() + ' by ' + HighScoreOFTHeDay.name );
        var highScoreSLineRender = highScoreSLine.render();
        
        var containerWidth = (highscoreFlineRender.width > highScoreSLineRender.width)? highscoreFlineRender.width : highScoreSLineRender.width;
        
        //BG Container
        ctx.globalAlpha = .2;
        ctx.fillStyle = '#000000';
        ctx.fillRect(10, 10, containerWidth + 6, 48); //canvasHeight - 10 - 24 - 10
        
        //Draw text
        ctx.globalAlpha = 1;
        ctx.drawImage(highscoreFlineRender, 12, 14);
        ctx.drawImage(highScoreSLineRender, 13, 38);
        
        return true;
    }

    function drawFpsStats(ctx) {
        
        //graphicMod.fps
        if (null == fpsText) {
            fpsText = new UText(14, '#bbbbbb');
        }
        fpsText.setValue('FPS ' + graphicMod.fps + ' Q: ' + graphicMod.selected);
        var c = fpsText.render();
        ctx.globalAlpha = .2;
        ctx.fillStyle = '#000000';
        
        var middleBottomWidth = Math.floor(canvasWidth/2);
        
        ctx.globalAlpha = 1;
        ctx.drawImage(c, middleBottomWidth - (c.width /2), canvasHeight - 20); //canvasHeight - 10 - 24 - 5
    }

    function drawTouch(ctx) {
        ctx.save();
        if (touchable) {
            for (var i = 0; i < touches.length; i++) {
                var touch = touches[i];
                if (touch.identifier == leftTouchID) {
                    ctx.beginPath();
                    ctx.strokeStyle = "#0096ff";
                    ctx.lineWidth = 6;
                    ctx.arc(leftTouchStartPos.x, leftTouchStartPos.y, 40, 0, Math.PI * 2, true);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.strokeStyle = "#0096ff";
                    ctx.lineWidth = 2;
                    ctx.arc(leftTouchStartPos.x, leftTouchStartPos.y, 60, 0, Math.PI * 2, true);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.strokeStyle = "#0096ff";
                    ctx.arc(leftTouchPos.x, leftTouchPos.y, 40, 0, Math.PI * 2, true);
                    ctx.stroke();
                } else {
                    ctx.beginPath();
                    ctx.beginPath();
                    ctx.strokeStyle = "#0096ff";
                    ctx.lineWidth = "6";
                    ctx.arc(touch.clientX, touch.clientY, 40, 0, Math.PI * 2, true);
                    ctx.stroke();
                }
            }
        }
        ctx.restore();
    }

    function drawGrid() {
        ctx.fillStyle = showDarkTheme ? "#111111" : "#F2FBFF";
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        ctx.save();
        ctx.strokeStyle = showDarkTheme ? "#AAAAAA" : "#000000";
        ctx.globalAlpha = .2;
        ctx.scale(viewZoom, viewZoom);
        var a = canvasWidth / viewZoom,
            b = canvasHeight / viewZoom;
    
        if(enableGrid) {
            ctx.beginPath();
            for (var c = -.5 + (-nodeX + a / 2) % 50; c < a; c += 50) {
                ctx.moveTo(c, 0);
                ctx.lineTo(c, b);
            }

            for (c = -.5 + (-nodeY + b / 2) % 50; c < b; c += 50) {
                ctx.moveTo(0, c);
                ctx.lineTo(a, c);
            }
        }
        ctx.stroke();
        ctx.restore();
        
    }

    function drawSplitIcon(ctx) {
        if (isTouchStart && splitIcon.width) {
            var size = ~~(canvasWidth / 7);
            ctx.drawImage(splitIcon, canvasWidth - size, canvasHeight - size, size, size);
        }

        if (isTouchStart && splitIcon.width) {
            var size = ~~(canvasWidth / 7);
            ctx.drawImage(ejectIcon, canvasWidth - size, canvasHeight - 2 * size - 10, size, size);
        }
    }

    function calcUserScore() {
        for (var score = 0, i = 0; i < playerCells.length; i++) score += playerCells[i].nSize * playerCells[i].nSize;
        return score
    }

    function drawLeaderBoard() {
        //Store mass
        playerStatistics.cellSizePlot.push(calcUserScore());
        
        lbCanvas = null;
        if (null != teamScores || 0 != leaderBoard.length)
            if (null != teamScores || showName) {
                lbCanvas = document.createElement("canvas");
                var ctx = lbCanvas.getContext("2d"),
                    boardLength = 60;
                boardLength = null == teamScores ? boardLength + 24 * leaderBoard.length : boardLength + 180;
                var scaleFactor = Math.min(0.22 * canvasHeight, Math.min(200, .3 * canvasWidth)) / 200;
                lbCanvas.width = 220 * scaleFactor;
                lbCanvas.height = boardLength * scaleFactor;

                ctx.scale(scaleFactor, scaleFactor);
                ctx.globalAlpha = .4;
                ctx.fillStyle = "#000000";
                ctx.fillRect(0, 0, 220, boardLength);

                ctx.globalAlpha = 1;
                ctx.fillStyle = "#FFFFFF";
                var c = "Leaderboard";
                ctx.font = "30px Ubuntu";
                //Draw lb title
                ctx.fillText(c, 110 - ctx.measureText(c).width / 2, 40);
                var b;
                if (null == teamScores) {
                    for (ctx.font = "20px Ubuntu", b = 0; b < leaderBoard.length; ++b) {
                        c = leaderBoard[b].name || "An unnamed cell";
                        if (!showName) {
                            (c = "An unnamed cell");
                        }
                        if (-1 != nodesOnScreen.indexOf(leaderBoard[b].id)) {
                            playerCells[0].name && (c = playerCells[0].name);
                            ctx.fillStyle = "#FFAAAA";
                            if (!noRanking) {
                                c = b + 1 + ". " + c;
                            }
                            ctx.fillText(c, 10, 70 + 24 * b);
                            playerStatistics.timeOnLeaderboard += 1; 
                            if((b + 1) == 1) playerStatistics.timeOnTopLeaderboard += 1;
                            
                        } else {
                            ctx.fillStyle = "#FFFFFF";
                            if (!noRanking) {
                                c = b + 1 + ". " + c;
                            }
                            //Old calc: 100 - ctx.measureText(c).width / 2
                            ctx.fillText(c, 10, 70 + 24 * b);
                        }
                    }
                } else {
                    for (b = c = 0; b < teamScores.length; ++b) {
                        var d = c + teamScores[b] * Math.PI * 2;
                        ctx.fillStyle = teamColor[b + 1];
                        ctx.beginPath();
                        ctx.moveTo(100, 140);
                        ctx.arc(100, 140, 80, c, d, false);
                        ctx.fill();
                        c = d
                    }
                }
            }
    }
    
    function drawMinimap() {
        var mmapWidth = 200;
        var mmapHeight = 200;
        
        if(playerCells.length > 0) {
            minimapData.cameraX = playerCells[0].x - minimapData.minx;
            minimapData.cameraY = playerCells[0].y - minimapData.miny;
        }
        
        //minimapData
        var minimapCanvas = document.createElement("canvas");
        var minimapCtx = minimapCanvas.getContext('2d');
        
        var scaleFactor = Math.min(0.22 * canvasHeight, Math.min(200, .3 * canvasWidth)) / 200;
        minimapCanvas.width = mmapWidth * scaleFactor;
        minimapCanvas.height = mmapHeight * scaleFactor;

        minimapCtx.scale(scaleFactor, scaleFactor);
        minimapCtx.globalAlpha = .4;
        minimapCtx.fillStyle = "#000000";
        minimapCtx.lineWidth = 1;
        minimapCtx.fillRect(0, 0, mmapWidth, mmapHeight);
        
        //Grid and naming
        var hGrid = [1, 2, 3, 4, 5, 6];
        var vGrid = [1, 2, 3, 4, 5, 6];
        
        var lineInterval = Math.floor(mmapWidth / 6);
        var halfLineInt = Math.floor(lineInterval / 2);
        minimapCtx.beginPath();
        minimapCtx.strokeStyle = "#ffffff";
        minimapCtx.globalAlpha = 0.7;
        minimapCtx.fillStyle = "#ffffff";
        
        minimapCtx.font = "15px Ubuntu";
                
        
        for(var vgc in vGrid) {
            var height = lineInterval * vgc;
            for(var hvc in hGrid) {
                var width = lineInterval * hvc;
                var c = String.fromCharCode(65 + parseInt(vgc))+''+(parseInt(hvc)+1);
                minimapCtx.fillText(c, width + halfLineInt - 8 ,  height + halfLineInt + 7);
            }
            
            //Draw vertical line
            minimapCtx.moveTo(0, height);
            minimapCtx.lineTo(mmapWidth, height);
        }
        for(var hvc in hGrid) {
            var width = lineInterval * hvc;
            minimapCtx.moveTo(width, 0);
            minimapCtx.lineTo(width, mmapHeight);
        }
        minimapCtx.moveTo(mmapWidth, 0);
        minimapCtx.lineTo(mmapWidth, mmapHeight);
        minimapCtx.moveTo(0, mmapHeight);
        minimapCtx.lineTo(mmapWidth, mmapHeight);
        minimapCtx.stroke();
        
        //Main dot
        var mainDotX = Math.floor((minimapData.cameraX / minimapData.mapWidth) * mmapWidth);
        var mainDotY = Math.floor((minimapData.cameraY / minimapData.mapHeight) * mmapHeight);
        
        minimapCtx.beginPath();
        minimapCtx.arc(mainDotX, mainDotY, 5, 0, 2 * Math.PI, false);
        minimapCtx.fillStyle = '#ffff00';
        minimapCtx.globalAlpha = 1;
        minimapCtx.fill();

        if(minimapCanvas && minimapCanvas.width) ctx.drawImage(minimapCanvas, canvasWidth - minimapCanvas.width - 10, canvasHeight - minimapCanvas.height - 10);
        
    }
    
    function Cell(uid, ux, uy, usize, ucolor, uname, a) {
        this.id = uid;
        this.ox = this.x = ux;
        this.oy = this.y = uy;
        this.oSize = this.size = usize;
        this.color = ucolor;
        this.points = [];
        this.pointsAcc = [];
        this.createPoints();
        this.setName(uname);
        this._skin = a;
    }

    function UText(usize, ucolor, ustroke, ustrokecolor) {
        usize && (this._size = usize);
        ucolor && (this._color = ucolor);
        this._stroke = !!ustroke;
        ustrokecolor && (this._strokeColor = ustrokecolor)
    }


    var localProtocol = window.location.protocol,
        localProtocolHttps = "https:" == localProtocol;
    var nCanvas, ctx, mainCanvas, lbCanvas, canvasWidth, canvasHeight, qTree = null,
        ws = null,
        nodeX = 0,
        nodeY = 0,
        nodesOnScreen = [],
        playerCells = [],
        nodes = {},
        nodelist = [],
        Cells = [],
        leaderBoard = [],
        rawMouseX = 0,
        rawMouseY = 0,
        X = -1,
        Y = -1,
        cb = 0,
        timestamp = 0,
        userNickName = null,
        leftPos = 0,
        topPos = 0,
        rightPos = 1E4,
        bottomPos = 1E4,
        viewZoom = 1,
        showSkin = true,
        showName = true,
        showColor = false,
        ua = false,
        userScore = 0,
        showDarkTheme = false,
        showMass = false,
        smoothRender = .4,
        posX = nodeX = ~~((leftPos + rightPos) / 2),
        posY = nodeY = ~~((topPos + bottomPos) / 2),
        posSize = 1,
        gameMode = "",
        teamScores = null,
        ma = false,
        hasOverlay = true,
        drawLine = false,
        lineX = 0,
        lineY = 0,
        drawLineX = 0,
        drawLineY = 0,
        teamColor = ["#333333", "#FF3333", "#33FF33", "#3333FF"],
        xa = false,
        zoom = 1,
        isTouchStart = "ontouchstart" in window && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        splitIcon = new Image,
        ejectIcon = new Image,
        noRanking = false;
    splitIcon.src = "assets/img/split.png";
    ejectIcon.src = "assets/img/feed.png";
    var wCanvas = document.createElement("canvas");
    var playerStat = null;
    window.isSpectating = false;


    setTimeout(function() {}, 3E5);
 


    var delay = 500,
        oldX = -1,
        oldY = -1,
        Canvas = null,
        z = 1,
        scoreText = null,
        fpsText = null,
        highScoreFline = null,
        highScoreSLine = null;
        skins = {},
        skinsPreloadImages = {},
        ib = ["_canvas'blob"];
    Cell.prototype = {
        id: 0,
        points: null,
        pointsAcc: null,
        name: null,
        nameCache: null,
        sizeCache: null,
        x: 0,
        y: 0,
        size: 0,
        ox: 0,
        oy: 0,
        oSize: 0,
        nx: 0,
        ny: 0,
        nSize: 0,
        flag: 0,
        updateTime: 0,
        updateCode: 0,
        drawTime: 0,
        destroyed: false,
        isVirus: false,
        isAgitated: false,
        wasSimpleDrawing: true,
        destroy: function() {
            var tmp;
            for (tmp = 0; tmp < nodelist.length; tmp++)
                if (nodelist[tmp] == this) {
                    nodelist.splice(tmp, 1);
                    break
                }
            delete nodes[this.id];
            tmp = playerCells.indexOf(this);
            if (-1 != tmp) {
                ua = true;
                playerCells.splice(tmp, 1);
            }
            tmp = nodesOnScreen.indexOf(this.id);
            if (-1 != tmp) {
                nodesOnScreen.splice(tmp, 1);
            }
            this.destroyed = true;
            if(graphicMod.fps > 0) {
                Cells.push(this);
            } else {
                Cells = [];
            }
        },
        getNameSize: function() {
            return Math.max(~~(.3 * this.size), 24)
        },
        setName: function(a) {
            this.name = a;
            if (null == this.nameCache) {
                this.nameCache = new UText(this.getNameSize(), "#FFFFFF", true, "#000000");
                this.nameCache.setValue(this.name);
            } else {
                this.nameCache.setSize(this.getNameSize());
                this.nameCache.setValue(this.name);
            }
        },
        createPoints: function() {
            for (var samplenum = this.getNumPoints(); this.points.length > samplenum;) {
                var rand = ~~(Math.random() * this.points.length);
                this.points.splice(rand, 1);
                this.pointsAcc.splice(rand, 1)
            }
            if (0 == this.points.length && 0 < samplenum) {
                this.points.push({
                    ref: this,
                    size: this.size,
                    x: this.x,
                    y: this.y
                });
                this.pointsAcc.push(Math.random() - .5);
            }
            
            while (this.points.length < samplenum) {
                var rand2 = ~~(Math.random() * this.points.length),
                    point = this.points[rand2];
            
                this.points.splice(rand2, 0, {
                    ref: this,
                    size: point.size,
                    x: point.x,
                    y: point.y
                });
                this.pointsAcc.splice(rand2, 0, this.pointsAcc[rand2])
            }
        },
        getNumPoints: function() {
            if (0 == this.id) return 16;
            var a = 10;
            if (20 > this.size) a = 0;
            if (this.isVirus) a = 30;
            var b = this.size;
            if (!this.isVirus)(b *= viewZoom);
            b *= z;
            if (this.flag & 32)(b *= .25);
            return ~~Math.max(b, a);
        },
        movePoints: function() {
            this.createPoints();
            
            for (var points = this.points, pointsacc = this.pointsAcc, numpoints = points.length, i = 0; i < numpoints; ++i) {
                var pos1 = pointsacc[(i - 1 + numpoints) % numpoints],
                    pos2 = pointsacc[(i + 1) % numpoints];
                pointsacc[i] += (Math.random() - .5) * (this.isAgitated ? 3 : 1);
                pointsacc[i] *= .7;
                10 < pointsacc[i] && (pointsacc[i] = 10); -
                10 > pointsacc[i] && (pointsacc[i] = -10);
                pointsacc[i] = (pos1 + pos2 + 8 * pointsacc[i]) / 10
            }
            for (var ref = this, isvirus = this.isVirus ? 0 : (this.id / 1E3 + timestamp / 1E4) % (2 * Math.PI), j = 0; j < numpoints; ++j) {
                var f = points[j].size,
                    e = points[(j - 1 + numpoints) % numpoints].size,
                    m = points[(j + 1) % numpoints].size;
                
                //deformation cellule
                if (15 < this.size && null != qTree && 20 < this.size * viewZoom && 0 != this.id) {
                    var l = false,
                        n = points[j].x,
                        q = points[j].y;
                    qTree.retrieve2(n - 5, q - 5, 10, 10, function(a) {
                        if (a.ref != ref && 25 > (n - a.x) * (n - a.x) + (q - a.y) * (q - a.y)) {
                            l = true;
                        }
                    });
                    if (!l && points[j].x < leftPos || points[j].y < topPos || points[j].x > rightPos || points[j].y > bottomPos) {
                        l = true;
                    }
                    if (l) {
                        if (0 < pointsacc[j]) {
                            (pointsacc[j] = 0);
                        }
                        pointsacc[j] -= 1;
                    }
                }
                f += pointsacc[j];
                0 > f && (f = 0);
                f = this.isAgitated ? (19 * f + this.size) / 20 : (12 * f + this.size) / 13;
                points[j].size = (e + m + 8 * f) / 10;
                e = 2 * Math.PI / numpoints;
                m = this.points[j].size;
                this.isVirus && 0 == j % 2 && (m += 5);
                points[j].x = this.x + Math.cos(e * j + isvirus) * m;
                points[j].y = this.y + Math.sin(e * j + isvirus) * m
            }
        },
        updatePos: function() {
            if (0 == this.id) return 1;
            var a;
            a = (timestamp - this.updateTime) / 120;
            a = 0 > a ? 0 : 1 < a ? 1 : a;
            var b = 0 > a ? 0 : 1 < a ? 1 : a;
            this.getNameSize();
            if (this.destroyed && 1 <= b) {
                var c = Cells.indexOf(this); -
                1 != c && Cells.splice(c, 1)
            }
            this.x = a * (this.nx - this.ox) + this.ox;
            this.y = a * (this.ny - this.oy) + this.oy;
            this.size = b * (this.nSize - this.oSize) + this.oSize;
            return b;
        },
        shouldRender: function() {
            if (0 == this.id) {
                return true
            } else {
                return !(this.x + this.size + 40 < nodeX - canvasWidth / 2 / viewZoom || this.y + this.size + 40 < nodeY - canvasHeight / 2 / viewZoom || this.x - this.size - 40 > nodeX + canvasWidth / 2 / viewZoom || this.y - this.size - 40 > nodeY + canvasHeight / 2 / viewZoom);
            }
        },
        drawOneCell: function(ctx) {
            if (this.shouldRender()) {
                var b = (0 != this.id && !this.isVirus && !this.isAgitated && smoothRender > viewZoom);
                if (10 > this.getNumPoints()) b = true;
                if (this.wasSimpleDrawing && !b)
                    for (var c = 0; c < this.points.length; c++) this.points[c].size = this.size;
                
                var bigPointSize = this.size;
                if(!this.wasSimpleDrawing) {
                    for (var c = 0; c < this.points.length; c++) bigPointSize = Math.max(this.points[c].size, bigPointSize);
                }
                                
                this.wasSimpleDrawing = b;
                ctx.save();
                this.drawTime = timestamp;
                c = this.updatePos();
                this.destroyed && (ctx.globalAlpha *= 1 - c);
                
                ctx.lineWidth = (this.size > 30)? 10:0; //Bordure
                ctx.lineCap = "round";
                ctx.lineJoin = this.isVirus ? "miter" : "round";
                if (showColor) {
                    ctx.fillStyle = "#FFFFFF";
                    ctx.strokeStyle = "#AAAAAA";
                } else {
                    ctx.fillStyle = this.color;
                    ctx.strokeStyle = this.color;
                }
                if (b) {
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI, false);
                } else {
                    this.movePoints();
                    ctx.beginPath();
                    var d = this.getNumPoints();
                    ctx.moveTo(this.points[0].x, this.points[0].y);
                    for (c = 1; c <= d; ++c) {
                        var e = c % d;
                        ctx.lineTo(this.points[e].x, this.points[e].y); //Draw circle of cell
                    }
                }
                ctx.closePath();
                
                var skinName = null;
                var nicknameBasedSkin = false; //Name based skin
                
                

                // Skin order from server side
                if(window.chMasterConfig.skin.indexOf(this.name.toLowerCase()) != -1) { //Name based skin
                    skinName = this.name.toLowerCase();
                    nicknameBasedSkin = true;
                } else if (typeof this._skin != 'undefined' && this._skin != '') {
                    if (this._skin[0] == '%') {
                        skinName = this._skin.substring(1);
                    }
                }
                //skinName = 'greenman';
                //Pas en teams, config loaded, skin found
                if (window.chMasterConfig && showSkin && ':teams' != gameMode && skinName != null) {
                    
                    //Image pas préchargée
                    if (!skins.hasOwnProperty(skinName)) {
                        skinsPreloadImages[skinName] = new Image;
                        skinsPreloadImages[skinName].src = window.chMasterConfig.skin_mirror + skinName + '.png';
                                                
                    }    
                    //Image préchargée mais pas convertie en canvas
                    if(skinsPreloadImages.hasOwnProperty(skinName) && !skins.hasOwnProperty(skinName)) {
                        
                        if (0 != skinsPreloadImages[skinName].width && skinsPreloadImages[skinName].complete) {
                            //Loading terminé
                            skins[skinName] = document.createElement('canvas');
                            skins[skinName].width = 512;
                            skins[skinName].height = 512;

                            var canvasCTX = skins[skinName].getContext("2d");
                            
                            canvasCTX.drawImage(skinsPreloadImages[skinName], 
                                                      0, 0, 512, 512,
                                                      0, 0, 512, 512);    
                        }        
                        
        
                    }
                    
                    if (skins.hasOwnProperty(skinName)) {
                        c = skins[skinName];
                    } else {
                        c = null;
                    }
                } else {
                    c = null;
                }

                c = (e = c) ? -1 != ib.indexOf(skinName) : false;
                b || ctx.stroke();
                ctx.fill();
                if (!(null == e || c)) {
                    ctx.save();
                    ctx.clip();
                    //Draw skin
                    ctx.drawImage(e, 
                                  this.x - bigPointSize, 
                                  this.y - bigPointSize, 
                                  2 * bigPointSize, 
                                  2 * bigPointSize);
                    ctx.restore();
                }
                if ((showColor || 15 < this.size) && !b) {
                    ctx.strokeStyle = '#000000';
                    ctx.globalAlpha *= .1;
                    ctx.stroke();
                }
                ctx.globalAlpha = 1;
                if (null != e && c) { 
                    ctx.drawImage(e, this.x - 2 * bigPointSize, this.y - 2 * bigPointSize, 4 * bigPointSize, 4 * bigPointSize);
                }
                c = -1 != playerCells.indexOf(this);
                var ncache;
                //draw name
                if (0 != this.id) {
                    var b = ~~this.y;
                    //Draw name on cell
                    if ((showName) && this.name && this.nameCache && !nicknameBasedSkin) {
                        ncache = this.nameCache;
                        ncache.setValue(this.name);
                        ncache.setSize(this.getNameSize());
                        var ratio = Math.ceil(10 * viewZoom) / 10;
                        ncache.setScale(ratio);
                        var rnchache = ncache.render(),
                            m = ~~(rnchache.width / ratio),
                            h = ~~(rnchache.height / ratio);
                        ctx.drawImage(rnchache, ~~this.x - ~~(m / 2), b - ~~(h / 2), m, h);
                        b += rnchache.height / 2 / ratio + 4
                    }

                    //draw mass
                    if (showMass && (c || 0 == playerCells.length && (!this.isVirus || this.isAgitated) && 20 < this.size)) {
                        if (null == this.sizeCache) {
                            this.sizeCache = new UText(this.getNameSize() / 2, "#FFFFFF", true, "#000000")
                        }
                        c = this.sizeCache;
                        c.setSize(this.getNameSize() / 2);
                        c.setValue(~~(this.size * this.size / 100));
                        ratio = Math.ceil(10 * viewZoom) / 10;
                        c.setScale(ratio);
                        e = c.render();
                        m = ~~(e.width / ratio);
                        h = ~~(e.height / ratio);
                        ctx.drawImage(e, ~~this.x - ~~(m / 2), b - ~~(h / 2), m, h);
                    }
                }
                ctx.restore()
            }
        }
    };
    UText.prototype = {
        _value: "",
        _color: "#000000",
        _stroke: false,
        _strokeColor: "#000000",
        _size: 16,
        _canvas: null,
        _ctx: null,
        _dirty: false,
        _scale: 1,
        setSize: function(a) {
            if (this._size != a) {
                this._size = a;
                this._dirty = true;
            }
        },
        setScale: function(a) {
            if (this._scale != a) {
                this._scale = a;
                this._dirty = true;
            }
        },
        setStrokeColor: function(a) {
            if (this._strokeColor != a) {
                this._strokeColor = a;
                this._dirty = true;
            }
        },
        setValue: function(a) {
            if (a != this._value) {
                this._value = a;
                this._dirty = true;
            }
        },
        render: function() {
            if (null == this._canvas) {
                this._canvas = document.createElement("canvas");
                this._ctx = this._canvas.getContext("2d");
            }
            if (this._dirty) {
                this._dirty = false;
                var canvas = this._canvas,
                    ctx = this._ctx,
                    value = this._value,
                    scale = this._scale,
                    fontsize = this._size,
                    font = fontsize + 'px Ubuntu';
                ctx.font = font;
                var h = ~~(.2 * fontsize);
                canvas.width = (ctx.measureText(value).width +
                    6) * scale;
                canvas.height = (fontsize + h) * scale;
                ctx.font = font;
                ctx.scale(scale, scale);
                ctx.globalAlpha = 1;
                ctx.lineWidth = 3;
                ctx.strokeStyle = this._strokeColor;
                ctx.fillStyle = this._color;
                this._stroke && ctx.strokeText(value, 3, fontsize - h / 2);
                ctx.fillText(value, 3, fontsize - h / 2)
            }
            return this._canvas
        },
        getWidth: function() {
            return (ctx.measureText(this._value).width +
                6);
        }
    };
    Date.now || (Date.now = function() {
        return (new Date).getTime()
    });
    var Quad = {
        init: function(args) {
            function Node(x, y, w, h, depth) {
                this.x = x;
                this.y = y;
                this.w = w;
                this.h = h;
                this.depth = depth;
                this.items = [];
                this.nodes = []
            }

            var c = args.maxChildren || 2,
                d = args.maxDepth || 4;
            Node.prototype = {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
                depth: 0,
                items: null,
                nodes: null,
                exists: function(selector) {
                    for (var i = 0; i < this.items.length; ++i) {
                        var item = this.items[i];
                        if (item.x >= selector.x && item.y >= selector.y && item.x < selector.x + selector.w && item.y < selector.y + selector.h) return true
                    }
                    if (0 != this.nodes.length) {
                        var self = this;
                        return this.findOverlappingNodes(selector, function(dir) {
                            return self.nodes[dir].exists(selector)
                        })
                    }
                    return false;
                },
                retrieve: function(item, callback) {
                    for (var i = 0; i < this.items.length; ++i) callback(this.items[i]);
                    if (0 != this.nodes.length) {
                        var self = this;
                        this.findOverlappingNodes(item, function(dir) {
                            self.nodes[dir].retrieve(item, callback)
                        })
                    }
                },
                insert: function(a) {
                    if (0 != this.nodes.length) {
                        this.nodes[this.findInsertNode(a)].insert(a);
                    } else {
                        if (this.items.length >= c && this.depth < d) {
                            this.devide();
                            this.nodes[this.findInsertNode(a)].insert(a);
                        } else {
                            this.items.push(a);
                        }
                    }
                },
                findInsertNode: function(a) {
                    return a.x < this.x + this.w / 2 ? a.y < this.y + this.h / 2 ? 0 : 2 : a.y < this.y + this.h / 2 ? 1 : 3
                },
                findOverlappingNodes: function(a, b) {
                    return a.x < this.x + this.w / 2 && (a.y < this.y + this.h / 2 && b(0) || a.y >= this.y + this.h / 2 && b(2)) || a.x >= this.x + this.w / 2 && (a.y < this.y + this.h / 2 && b(1) || a.y >= this.y + this.h / 2 && b(3)) ? true : false
                },
                devide: function() {
                    var a = this.depth + 1,
                        c = this.w / 2,
                        d = this.h / 2;
                    this.nodes.push(new Node(this.x, this.y, c, d, a));
                    this.nodes.push(new Node(this.x + c, this.y, c, d, a));
                    this.nodes.push(new Node(this.x, this.y + d, c, d, a));
                    this.nodes.push(new Node(this.x + c, this.y + d, c, d, a));
                    a = this.items;
                    this.items = [];
                    for (c = 0; c < a.length; c++) this.insert(a[c])
                },
                clear: function() {
                    for (var a = 0; a < this.nodes.length; a++) this.nodes[a].clear();
                    this.items.length = 0;
                    this.nodes.length = 0
                }
            };
            var internalSelector = {
                x: 0,
                y: 0,
                w: 0,
                h: 0
            };
            return {
                root: new Node(args.minX, args.minY, args.maxX - args.minX, args.maxY - args.minY, 0),
                insert: function(a) {
                    this.root.insert(a)
                },
                retrieve: function(a, b) {
                    this.root.retrieve(a, b)
                },
                retrieve2: function(a, b, c, d, callback) {
                    internalSelector.x = a;
                    internalSelector.y = b;
                    internalSelector.w = c;
                    internalSelector.h = d;
                    this.root.retrieve(internalSelector, callback)
                },
                exists: function(a) {
                    return this.root.exists(a)
                },
                clear: function() {
                    this.root.clear()
                }
            }
        }
    };

    //window.onload = gameLoop;
    
 
    
})(window, window.jQuery);
