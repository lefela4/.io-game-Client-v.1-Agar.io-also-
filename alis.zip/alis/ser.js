//Client Settings
var uuid = null;
require("colors");
//Server Settings
var http_Port = 8082;
var slave_Port = 8092;


//Http Server
var express = require('express');
var app = express();
var serveIndex = require('serve-index');
app.use(express.static(__dirname + "/"));
app.use('/files', serveIndex(__dirname + '/files'));
app.listen(http_Port);

var token = [];


//Slaves Server
var app_slave = require('express')();
var http_slave = require('http').Server(app_slave);
var io_slave = require('socket.io')(http_slave);
app_slave.get('/', function(req, res){
    res.end('');
});

io_slave.on('connection', function(socket){
    socket.emit("connected");
	socket.on("token", function(data) {
		
		console.log("New token: " + data.token);
		
	});
	
});
http_slave.listen(slave_Port, function(){});